binplot <-
function(filepath,nr=20,nc=20, scale="raw") {
  table1 <- read.table(filepath,sep='\t',header = F)
  x = table1[,1] ; y = table1[,2]
  zx = c(1:nr,rep(1,nc),1+trunc( nr*(x- min(x))/(max(x)-min(x)) ))
  zx[zx>nr] = nr
  zy = c(rep(1,nr),1:nc,1+trunc( nc*(y- min(y))/(max(y)-min(y)) ))
  zy[zy>nc] = nc
  z = table(zx,zy); z[,1]=z[,1]-1; z[1,]=z[1,]-1;
  if (scale=="l") z= log(1+z)
  zones=matrix(c(2,0,1,3), ncol=2, byrow=TRUE)
  layout(zones, widths=c(4/5,1/5), heights=c(1/5,4/5))
  xhist = hist(zx,plot=FALSE)
  yhist = hist(zy, plot=FALSE)
  top = max(c(xhist$counts, yhist$counts))
  bot = min(c(xhist$counts, yhist$counts))
  par(mar=c(3,3,1,1))
  image(z=t(z),x=seq(length=nr+1,from=min(x),to=max(x)),
        y= seq(length=nc+1,from=min(y),to=max(y)),
        xlab="X-axis",ylab="Y-axis", col=heat.colors(200))
  par(mar=c(0,3,1,1))
  barplot(xhist$counts, axes=FALSE, ylim=c(bot, top), space=0)
  par(mar=c(3,0,1,1))
  barplot(yhist$counts, axes=FALSE, xlim=c(bot, top), space=0, horiz=TRUE)
  par(oma=c(3,3,0,0))
}
