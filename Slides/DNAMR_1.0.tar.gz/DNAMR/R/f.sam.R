f.sam <-
function( x, y, delta, ns=100, delgr=2) 
{ 
  n1 <- ncol(x); n2 <- ncol(y); n <- n1+n2 
  
  ## Convert data into matrix format
  x <- f.toarray(x)
  y <- f.toarray(y)
  ## Delete missing values
  i <- !is.na( x%*%rep(1,n1) + y%*%rep(1,n2) )
  x <- x[i,]; y <- y[i,]

  ng <- sum(i)
  ## Calculate the SAM constant
  con <- f.fudge.factor(x,y)
  ## Perform permutation argument
  to <- f.samperm(x,y,con,ns)
  db <- f.rmean(to) 
  d <- f.rtt( x, y, con ) 
  dimnames(d) <- list(NULL, dimnames(x)[[1]])
  ii <- sort.list(d);     
  d <- d[,ii] # let d keep gene names 
  clow <- cup <- sn <- NULL 
  if ( missing(delta)) {
    qd <- round(quantile(abs(db-d),c(0.2,0.999)),2)
    bb <- (qd[2] - qd[1])/15
    b0 <- 10^-floor(log(bb,10))
    bb <- trunc(bb*b0)/b0
    delta <- seq( from=qd[1],to=qd[2],by=bb)
  } 
  nsn  <- array( 0, c(length(delta),2) ) 
  ## Draw the basic SAM graph 
  par(pty="s") 
  rr <- range( c(d,db) ) 
  plot( rr, rr, type="n", xlab="Ave d(i)", ylab="d(i)" ) 
  significant <- abs(db-d) > delgr 
  points( d[!significant], db[!significant], col=4 )
  points( d[significant], db[significant], col=2 ) 
  abline( 0, 1 ) 
  abline( delgr, 1, col=3 ) # the upper threshold 
  abline(-delgr, 1, col=3 ) # the lower threshold 
  abline( h=0, v=0 ) # the coordinate axis through the origin 
  ## Calculate the FP, Called, FDR 
  for ( i in 1:length(delta) ) { 
    clow[i] <- max( d[sig.induced <- d < (db-delta[i])] ) 
    cup[i]  <- min( d[sig.repressed <- d > (db+delta[i])] ) 
    sn[i]   <- sum(sig.induced) + sum(sig.repressed) 
    qq <- c( rep(1,nrow(to))%*% ( (to > cup[i]) | (to < clow[i])) )   
    nsn[i,] <- quantile( qq, c(0.5,0.9) ) 
  } 
  prun <- quantile( to, c(0.25, 0.75) ) 
  p    <- min( sum(d <prun[2] & d > prun[1])/ng*2, 1 ) 
  nsn  <- nsn*p 
  ## Output. 
  statistics = cbind( ii, abs(db-d) ) 
  dimnames(statistics)[[2]] <- c("Row.number", "Delta")
  list( round( cbind( Delta = delta, 
                      "FalsePositive50%" = nsn[,1], 
                      "FalsePositive90%" = nsn[,2], 
                      Called = sn, 
                      "FDR50%" = nsn[,1]/sn, 
                      "FDR90%" = nsn[,2]/sn ), 
               4 ), 
        statistics,
        attr(d, "names")[significant] ) 
}

