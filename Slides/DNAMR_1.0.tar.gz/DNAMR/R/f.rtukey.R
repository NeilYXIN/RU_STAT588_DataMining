f.rtukey <-
function(x,gr, ret.pval=F, conf.level=0.95){
if(!is.matrix(x)) x = f.toarray(x)
  xm <- f.cmat(x,gr)
  ngr <- ncol(xm)
  tgr <- table(gr)
  y <- nn <- NULL
  for(i in 2:ngr) {
    y = cbind( y, xm[,i:ngr]-xm[,i-1])
    nn = c(nn,1/tgr[i:ngr]+1/tgr[i-1]) 
  }
  ncy <- ncol(y) 
  nms <- as.character(unique(gr))
  nms <- outer(nms, nms, paste, sep = "-")
  nms <- dimnames(y)[[2]] <- nms[lower.tri(nms)]
  nms1 <- c(rbind(nms,paste("pv",nms,sep="")),"Rank") 
  nms2 <- c(rbind(nms,paste("Sign.",nms,sep="")),"Sign.","Rank") 
  MSE <- f.rmse(x,gr)
  df = sum(tgr -1) 
  # width <- qtukey(conf.level, ngr, df)*sqrt(outer(MSE/2,nn, "*"))
  yy = y/sqrt(outer(MSE/2,nn, "*"))
  absyy= abs(yy)
  generank = rank( -eval(parse(text=paste("pmax(",paste("absyy[,",1:ncy,"]",sep="",collapse=","),")",sep=""))))
  if(ret.pval) {
       qq <- sort(c( absyy[absyy> quantile(absyy,0.95)],
            quantile(absyy, (0:95)/100)))
       ptk <- ptukey(qq,ngr,df)
       qtk <-sqrt(-log(1-ptk/1.0001))
	tt <- approx(qq,qtk,absyy)$y
        ytukey= 1.0001*(1-exp(-array(tt,dim=dim(yy))^2))
        tt=cbind(yy,1-ytukey)
#        tt1=cbind(yy,1-ptukey(yy,ngr,df))
        tt= data.frame(tt[,c(rbind(1:ncy,ncy+1:ncy))],Rank=generank)
        names(tt) = nms1
  }
  else {
       sign <- abs(y) > qtukey(conf.level, ngr, df)*sqrt(outer(MSE/2,nn, "*"))
       tt <- data.frame( round(yy,6),array(c("NS","S")[1+sign],dim=dim(y))) 
       tt = cbind( tt[,c(rbind(1:ncy,ncy+1:ncy))],c("No","Yes")[1+(f.rmean(sign)>0)],generank)
       names(tt)=nms2
   }
   tt[sort.list(generank),]
}

