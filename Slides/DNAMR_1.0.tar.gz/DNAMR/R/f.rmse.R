f.rmse <-
function(x, gr) {
  xm <- f.rmean(x)
  SSB<- f.csum(t((f.cmat(x, gr) - xm)^2) * c(table(gr)))
  SST<- f.rsum((x - xm)^2)
  (SST-SSB)/sum(table(gr)-1)
}

