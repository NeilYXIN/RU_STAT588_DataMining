f.pow <-
function( x,gg=gg,a= c(-30,0.1),method="multidim",k=40) {
if(substring(method,1,1)=="m") optim(a,f.tar1,z=x,gg=gg)
else {
aa=a[1]
for(i in 1:k) { 
a[1]=optimize( f.tar0,c(aa,min(z)),b=a[2],z=z,gg=gg)$min
a[2]= optimize( f.tar0, c(-5,2), a= a[1],z=z,gg=gg)$min
}
}
return(a)
}

