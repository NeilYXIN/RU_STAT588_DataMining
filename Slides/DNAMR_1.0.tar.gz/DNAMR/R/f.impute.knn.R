f.impute.knn <-
function(x, k = 2, min.row=3, min.col=k) { 
# Arguments:
#  x : array only. Dataframe is not allowed.
#  k : Number of nearest neighbors to estimate missing obs.
#  min.row: The minimum number of non missing values in a row. If there 
#     are fewer, then the row is discarded.
#  min.col: The minimum number of non missing values in a sample. If there 
#     are fewer, then the sample is discarded. As a deafult is set to k.
#
 n <- nrow(x); m <- ncol(x)
   ina <- is.na(x)
   mna <- c(rep(1,n)%*%(!ina))
   if(any(mna < min.col)) {
       warning(paste("Column-s ", paste((1:m)[mna<min.col],collapse=",")," were deleted because they have fewer than ",min.col," values.",sep=""))
       x <- x[,mna >= min.col] 
       m <- ncol(x)
     ina <- ina[,mna >= min.col] 
   } 
   nna <- c((!ina)%*% rep(1,m))
   if(any(nna < min.row)) {
       warning(paste("Row-s ", paste((1:n)[nna<min.row],sep=",")," were deleted becuase they have fewer than ",min.row," values.",sep=""))
       x <- x[nna >= min.row,]
       n <- nrow(x)
       ina <- ina[nna >= min.row,];nna <- nna[nna >= min.row]  
   } 
   x1 <- x
   nk <- (1:n)[nna<m]
   for(i in nk) {
       ii <- ina[i,]
       iina <- c(ina[,!ii]%*%rep(1,mm <-sum(!ii)))
       dd <-0
       for(w in 1:10) {
           jj <- iina <=dd
           ina[jj,ii,drop=F]
           if( all( c(rep(1,sum(jj))%*%!ina[jj,ii,drop=F]) >=k)) break
           else dd <- dd+1
       }
       xx <- x[iina <=dd,,drop=F]
       dx <- f.rmean(t((t(xx[,!ii]) -x[i,!ii])^2))
       est <- apply( xx[sort.list(dx),ii,drop=F],2,function(x)mean(x[!is.na(x)][1:k])) 
       x1[i,ii] <- est
   }
   x1
}

