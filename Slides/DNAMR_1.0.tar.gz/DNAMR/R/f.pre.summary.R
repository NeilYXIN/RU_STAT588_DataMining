f.pre.summary <-
function(x,k=0,npages=1 ) { # Summary about transformations
        p <- ncol(x)
        x <- data.frame(x)
        pp = ceiling(p/npages)
         par(mfcol=c(4,pp))
        par(mar=c(3,1,3,1))
        nam <- names(x)
        nam1 <- paste ("Log(",nam,")",sep="")
        lx <- log(x-k)
        for( i in 1:p) {
          hist(x[[i]],main=nam[i])
          qqnorm(x[[i]],main=nam[i])
          hist(lx[[i]],main=nam1[i])
          qqnorm(lx[[i]],main=nam1[i])
        }
        invisible()  ##
}

