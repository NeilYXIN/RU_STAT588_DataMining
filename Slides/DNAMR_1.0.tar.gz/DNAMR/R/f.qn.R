f.qn <-
function(x) {
# This function performs a quantile normalization on a GSM X
# Missing values are not allowed
        xm <- apply(x,2,sort)
        xxm <- f.rmedian.na(xm)
        xr <- c(apply(x,2,rank))
        array( approx(1:nrow(x),xxm,xr)$y, dim(x),dimnames(x))
  }

