f.cluster <-
function(X, logtran=T ,kval=0, qnorm=T ,retall=T,retnclust=1,
nclust=5 ,opt=4,maxng=100) {
X <- f.toarray(X)
if(is.na(kval) | !(kval > -Inf)) kval <- 0
if (logtran) X<- log(X-kval)
if(qnorm) X <- f.qn(X)
X <- X[f.corsub(X,maxng),]
opp = list("single","complete", "average","ward", "mcquitty", "median","centroid")
names(opp)=c("single","complete", "average","ward", "mcquitty", "median","centroid")
opt=opp[[opt]][1]
hh <- hclust(dist(X), method= opt)
plot(hh,hang=-0.1)
tt <- NULL
for(i in 1:20) tt[i] <-f.rsq( t(X),cutree(hh,i))
nc<- sort.list(exp(-diff(log(diff(tt)))))[18]+1
as.matrix(cutree(hh,nc))
}

