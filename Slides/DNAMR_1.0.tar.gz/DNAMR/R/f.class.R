f.class <-
function(X,Y, logtran=T ,kval=0, qnorm=T,retgenes=T,ngenes=100,  
 retnpc=T,npc=2, opt="lda",trcolname=T, trrand=F, trrandpct=50, trcv=F, cvk=1) {
 library(MASS)
 library(class)
 library(nnet)
  if (any(i<-is.na(Y))) { Y=Y[!i]; X <- X[,!i]}  
  X <- f.toarray(X)
  p <- ncol(X)
  if(is.na(kval) | !(kval > -Inf)) kval <- 0
  if (logtran) X <- log(X-kval)
  if(qnorm) X <- f.qn(X)
  if (retgenes<1) ngenes <- 100
  if (retnpc<1) npc <- 5
  WW <- f.summ(X,Y,npc,ngenes)
if(trcolname) {
          itrain <- grep("TRAIN", dimnames(X)[[2]])
          itest <- grep("TEST", dimnames(X)[[2]])
  } else if (trrand ) {
     pk = table(Y)
     cumpk= c(0,cumsum(pk))
     mpk =  sort.list(-pk)[1]
     m  <-p*trrandpct/100
     pm  <-round(pk*trrandpct/100)
     pm[mpk] = m - sum(pm[-mpk])
     itrain <- NULL
     for(i in 1: length(pk)) itrain <- c(itrain,cumpk[i]+ sample(pk[i],pm[i],rep=F))
	itrain <- sort(itrain)
     cat(itrain)
     itest  <- (1:p)[-itrain]
     cat(itest)
  } else if(trcv) {
     itrain <- 1:p
     itest <- numeric(0)
  }
  W <-data.frame(WW[itrain,],Y=Y[itrain])   
  Wc <-data.frame(WW[itest,],Y=Y[itest])   
browser()
  if(opt=="lda") {
        z <- lda(Y ~ ., data=W,CV=T);zclass=as.character(z$class)
        u <- table(W$Y,zclass)
        dimnames(u)[[1]] <- paste("Observed", dimnames(u)[[1]])
        dimnames(u)[[2]] <- paste("Predicted",dimnames(u)[[2]])
        w <- data.frame(zclass,round(z$posterior,3))
        dimnames(w)[[2]] <- c("Group",paste("Prob.Class",sort(unique(Y[itrain])),sep="_"))
     if(length(itest) > 0) {
        zt <- predict(lda(Y ~ ., data=W),Wc)
        ut <- table(Y[itest],zt$class)
       dimnames(ut)[[1]] <- paste("Observed", dimnames(ut)[[1]])
        dimnames(ut)[[2]] <- paste("Predicted",dimnames(ut)[[2]])
browser(); 
        wt <- data.frame(as.character(zt$class),round(zt$posterior,3))
        dimnames(wt)[[2]] <- c("Group",paste("Prob.Class",sort(unique(Y[itrain])),sep="_"))
        return(list('Linear discr anal. Performance Assesment Table For Training Set'=u,TrainingSet=w,
               'Linear discr anal. Performance Assesment Table For Testing Set'=ut,TestSet=wt))
     } else return(list('Linear discr anal. Performance Assesment Table For Training Set'=u,TrainingSet=w))
  }
  if(opt=="qda") {
        z <- qda(factor(Y) ~ ., data=W,CV=T)
        u <- table(W$Y,z$class)
        dimnames(u)[[1]] <- paste("Observed", dimnames(u)[[1]])
        dimnames(u)[[2]] <- paste("Predicted",dimnames(u)[[2]])
        w <- data.frame(z$class,round(z$posterior,3))
        dimnames(w)[[2]] <- c("Group",paste("Prob.Class",sort(unique(Y[itrain])),sep="_"))
     if(length(itest) > 0) {
        zt <- predict(qda(Y ~ ., data=W),data.frame(WW[itest,]))
        ut <- table(Y[itest],zt$class)
        dimnames(ut)[[1]] <- paste("Observed", dimnames(ut)[[1]])
        dimnames(ut)[[2]] <- paste("Predicted",dimnames(ut)[[2]])
        wt <- data.frame(zt$class,round(zt$posterior,3))
        dimnames(wt)[[2]] <- c("Group",paste("Prob.Class",sort(unique(Y[itrain])),sep="_"))
        return('Quadratic discr anal. Performance Assesment Table For Training Set'=u,TrainingSet=w,
               'Quadratic discr anal. Performance Assesment Table For Testing Set'=ut,TestSet=wt)
     } else return('Quadratic discr anal. Performance Assesment Table For Training Set'=u,TrainingSet=w)
  }
  if(opt=="knn") {
        z <- knn.cv(WW[itrain,],Y[itrain],k=5,prob=T)
        u <- table(Y[itrain],z )
        dimnames(u)[[1]] <- paste("Observed", dimnames(u)[[1]])
        dimnames(u)[[2]] <- paste("Predicted",dimnames(u)[[2]])
        w <- data.frame(z,attr(z,"prob"))
        dimnames(w)[[2]] <- c("Classification Group","Prob.Class")
     if(length(itest) > 0) {
        zt <- knn(WW[itrain,],WW[itest,],Y[itrain],k=5,prob=T)
        ut <- table(Y[itest],zt )
        dimnames(ut)[[1]] <- paste("Observed", dimnames(ut)[[1]])
        dimnames(ut)[[2]] <- paste("Predicted",dimnames(ut)[[2]])
        wt <- data.frame(zt,attr(zt,"prob"))
        dimnames(wt)[[2]] <- c("Classification Group","Prob.Class")
        return('K-nearest neighbours anal(K=5). Performance Assesment Table Training Set'=u,
        'Classification Training'=w,'Performance Assesment Table Testing Set'=ut,'Classification Testing'=wt)
     } else return('K-nearest neighbours anal(K=5). Performance Assesment Table For Training Set'=u,TrainingSet=w)
    }
  if(opt=="ann") {
        w <- f.anncv(W) 
        u <- table(W$Y,w[,1])
        dimnames(u)[[1]] <- paste("Observed", dimnames(u)[[1]])
        dimnames(u)[[2]] <- paste("Predicted",dimnames(u)[[2]])
        dimnames(w)[[2]] <- c("Class.Group",paste("Prob.Class",sort(unique(W$Y)[1:(ncol(w)-1)]),sep="_"))
        if(length(itest) > 0) {
          z <- nnet(factor(Y)~.,data=W,maxit=300,skip=T,size=10)
          wwt <- round(predict(z,WW[itest,]),4)
          wt <- predict(z,WW[itest,],type="class")
          ut <- table(Y[itest],wt)
          dimnames(ut)[[1]] <- paste("Observed", dimnames(ut)[[1]])
          dimnames(ut)[[2]] <- paste("Predicted",dimnames(ut)[[2]])
          wt <- data.frame(wt,wwt)
          dimnames(wt)[[2]] <- c("Class. Group",paste("Prob.Class",sort(unique(W$Y)),sep="_"))
          return(
          'Neural Net. Performance Assesment Table for Training Set'=u,
          'Classification for Training Set'=w,
          'Performance Assesment Table for Testing Set'=ut,
          'Classification for Testing Set'=wt)
        } else {
        return('Neural Net. Performance Assesment Table for Training Set'=u,
               'Classification for Training Set'=w) }
  }
  if(opt=="pam") {
	u <- f.pam(X[,itrain],Y[itrain])
        v <- table(Y[itrain],u[[1]])
        dimnames(v)[[1]] <- paste("Observed", dimnames(v)[[1]])
        dimnames(v)[[2]] <- paste("Predicted",dimnames(v)[[2]])
      if(length(itest) > 0) {
		ut =f.pam.predict(X[,itest],u)
		wt = table(Y[itest],ut)	
        dimnames(wt)[[1]] <- paste("Observed", dimnames(wt)[[1]])
        dimnames(wt)[[2]] <- paste("Predicted",dimnames(wt)[[2]])
         list(
          'PAM. Performance Assesment Table for Training Set'=v,
          'Classification for Training Set'=as.matrix(u[[1]]),
          'Performance Assesment Table for Testing Set'=wt,
          'Classification for Testing Set'=as.matrix(ut))
         } else
        list('PAM. Performance Assesment Table for Training Set'=v,
               'Classification for Training Set'=as.matrix(u[[1]]))
  }
  if(opt=="svm") {
        library(e1071)
	u <- svm(factor(Y) ~ ., data=W); zclass = as.charcter(u$fitted)
        v <- table(W$Y,zclass)
        dimnames(v)[[1]] <- paste("Observed", dimnames(v)[[1]])
        dimnames(v)[[2]] <- paste("Predicted",dimnames(v)[[2]])
      if(length(itest) > 0) {
		ut =f.pam.predict(X[,itest],u)
		wt = table(Y[itest],ut)	
        dimnames(wt)[[1]] <- paste("Observed", dimnames(wt)[[1]])
        dimnames(wt)[[2]] <- paste("Predicted",dimnames(wt)[[2]])
         list(
          'PAM. Performance Assesment Table for Training Set'=v,
          'Classification for Training Set'=as.matrix(u[[1]]),
          'Performance Assesment Table for Testing Set'=wt,
          'Classification for Testing Set'=as.matrix(ut))
         } else
        list('PAM. Performance Assesment Table for Training Set'=v,
               'Classification for Training Set'=as.matrix(u[[1]]))
  }
}

