f.mad <-
function(x) median(abs(x-median(x)))

