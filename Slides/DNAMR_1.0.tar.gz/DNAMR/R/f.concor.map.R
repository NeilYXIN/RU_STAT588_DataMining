f.concor.map <-
function(x,y) if(missing(y)) f.image(f.concor(x)) else f.image(f.concor(x,y))

