f.log <-
function(z,gg) 
optimize(f.tar2,interval=c(-10^7,min(z)),z=z,gg=gg)$min

