f.bplot <-
function(z,rid,cid,w=c(0,5,10,50,100,200),col=heat.colors(100)){ 
    if(missing(rid)) rid = rep(1,nrow(z))
    if(missing(cid)) cid = rep(1,ncol(z))
    zz= (z -min(z))
    zz = zz/max(zz)
    kk <- length(unique(rid))
    n <- nrow(zz)
    ss <- length(unique(cid))
    nc <- ncol(zz)
    sk <- max(c(15/ss, 2))
    sk2 <- max(c(12/kk, 2))
    ii <- sort.list(rid)
    jj <- sort.list(cid)
    mm <- rbind(c(0, rep(1, ss), 0), cbind(2, array(3, c(kk, 
        ss)), 3 + (1:kk)), c(0, rep(kk + 4, ss), 0))
    nf <- layout(mm, c(1, rep(sk, ss), 6), c(1, rep(2*sk2, kk), 
        1), TRUE)
    layout.show(nf)
    par(mar = c(0, 1, 0.5, 0))
    y <- table(cid)
    y <- cumsum(y) - y/2
    image(1:nc, 1, 1 + array((cid[jj]), c(nc, 1))%%2, zlim = c(0, 
        2), col = col, add = F, axes = F)
    text(y, rep(1, ss), paste("C", 1:ss, sep = ""))
    box()
    par(mar = c(1, 0.5, 1, 0))
    y <- rev(table(rid))
    y <- cumsum(y) - y/2
    image(1, 1:n, 1 + array(rev(rid[ii]), c(1, n))%%2, xlim = c(0.5, 
        2), zlim = c(0, 2), col = col, add = F, axes = F)
    text(rep(1.3, kk), y + 0.8, rev(LETTERS[1:kk]))
    box()
    zzz <- (t(as.matrix(zz)))[sort.list(cid), sort.list(rid)]
    zzz <- zzz[, ncol(zzz):1]
    par(mar = c(1, 1, 1, 0))
    image(1:nc, 1:ncol(zzz), zzz, xlab = "", ylab = "", add = F, 
        col = col, axes = F)
    box()
    par(mar = c(0, 2, 1, 1), cex = 0.5)
    for (i in 1:kk) {
        j <- rid == i
        y <- apply(as.matrix(zz[j, ]), 2, mean)
        y <- y/max(y)
        plot(1:nc, y, ylim = c(0, 1.01), type = "l", lty = 1, 
            las = 1, ylab = "", xlab = "", axes = F)
        text(1:nc, rep(-0.15, nc), labels = names(zz))
        text(rep(-0.05, 3), c(0, 0.5, 1), labels = c("0.0", "0.5", 
            "1.0"))
        box()
        title(paste(LETTERS[i], ": ", sum(j), " Genes"))
    }
    par(cex = 0.7)
    par(mar = c(0.7, 1, 0, 0))
    y <- seq(from = min(zzz), to = max(zzz), length = 100)
    dim(y) <- c(100, 1)
    image(c(y), 1, y, add = F, col = col, axes = F)
    ll <- round(y[seq(from = 10, to = 90, length = 9)], 1)
    box()
    text(ll, rep(1, 9), ll)
    par(mfrow=c(1,1))
}

