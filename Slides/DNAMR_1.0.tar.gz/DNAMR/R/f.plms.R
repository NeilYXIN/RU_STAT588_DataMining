f.plms <-
function(exx,...) {
  xm <- rmean(exx)
  sx <- rsd(exx)
  plot(log(xm),log(sx),...)
  lines(smooth.spline(log(xm),log(sx)),lwd=3,col=2)
  abline(v=median(log(xm)),col=4)
  invisible() 
}

