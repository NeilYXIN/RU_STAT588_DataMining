f.rave <-
function(x)  { 
# The function is given below. The input "x" is a GxR matrix of intensities with 
# G genes along the rows and R replicates (e.g., 4 similar panels) along the 
# columns. The output is a G-vector of robust averages. 
    library(modreg)
    x = matrix( as.numeric( as.matrix(x) ), nrow=nrow(x) ) 
    if(ncol(x)==1) return(c(x))
    mx <- apply(x, 1, median, na.rm = T)
    ssx <- apply(abs(x-mx),1,mean,na.rm=T) 
    mx2 <- rep(mx, ncol(x)) 
    xx <- c(x) 
    jj <- is.na(mx) 
    ii <- is.na(mx2) | is.na(xx) 
    sx <- rep(NA, length(mx)) 
    sx[!jj] <- predict(loess(abs(xx[!ii] - mx2[!ii]) ~ mx2[!ii]), mx[!jj])
    sx <- pmax(sx,ssx)
    f.rmest( x, mu=mx,s=sx) 
}

