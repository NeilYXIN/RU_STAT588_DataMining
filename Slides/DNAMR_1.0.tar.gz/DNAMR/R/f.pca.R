f.pca <-
function(x)  {
    ca<- match.call()
    if (ncol(x) > nrow(x)) {
        u=princomp(t(x))
        u$call=ca; return(u)}
    xb <- x - (mu <- f.rmean(x))
    xb.svd <- svd(xb)
    u <- t(xb) %*% xb.svd$u
    dimnames(u)[[2]] <- paste("PC", 1:ncol(u), sep = "")
    l <- xb.svd$u
    dimnames(l) <- list(paste("V",1:nrow(l),sep=""), paste("Comp.",1:ncol(l),sep=""))
    class(l) <-"loadings"
    sd= xb.svd$d/sqrt(ncol(x));
    names(sd) <- paste("Comp.",1:length(sd),sep="") 
    u <- list(sdev =sd , loadings = l, 
        center = mu, scale = rep(1, length(mu)), n.obs = ncol(x), 
        scores = u, call=ca)
    class(u) <- "princomp"
    return(u)
}

