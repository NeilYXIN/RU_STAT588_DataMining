f.rtt <-
function(x1,x2,fu=0,num.thresh=10^(-6),denom.thresh=10^(-6)) { 
    num = (f.rmean(x1)-f.rmean(x2)) 
    den = (t(array(fu,c(nrow(x1),length(fu))))+f.rssp(x1,x2)) 
    i = abs(num ) < num.thresh & den < denom.thresh
    num[i]=0; den[i]=1 
    num/den 
 }

