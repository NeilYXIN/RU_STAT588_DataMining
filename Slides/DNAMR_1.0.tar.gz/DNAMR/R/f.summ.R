f.summ <-
function(x,y,npc,ng) {
       z <- f.F(x,y)
       if(missing(ng)) ng <- 1000
       i <- sort.list(z[,2])[1:ng]
       x <- x[i,]
       xpc <- f.pca(x)
       k <- xpc$sdev^2
       k <- sum(k > mean(k))
       if(missing(npc)) npc <- k
       xpc$scores[,1:npc]
}

