f.rsd <-
function(x) sqrt(f.rvar(x))

