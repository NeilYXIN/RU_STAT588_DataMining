f.rvar <-
function(x,n=ncol(x)) c((x-f.rmean(x))^2 %*%rep(1,n))/(n-1)

