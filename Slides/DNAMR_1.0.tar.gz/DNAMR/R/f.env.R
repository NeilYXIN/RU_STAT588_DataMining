f.env <-
function(x,y,x0=x,y0=y,type= c("dec","inc","none")[3], m=20,lqi=0.05,hqi=0.95,sym=F,plot=T,flag=F,dg=8,logtran=F) {
#  x, y are the coordinates of the points used to generate the
#       envelope.
#  x0, y0 are the points that are graphed with the envelop.
#        By default x0=x y0=y
#  type:  constraints to the envelop function, increasing decreasing or none. 
#  m = block size for constructing the quantile envelop
    qi <- c(if(!is.null(lqi)) sort(lqi),if(!is.null(hqi)) sort(hqi))
    if (logtran){x = log(x); x0 = log(x0); y =log(y); y0= log(y0)}
    if(sym) {
       qi = unique(sort(pmax(qi,1-qi))); lqi <- NULL; y1= abs(y)} else {y1=y}
    n <- length(x)
    n1 <- n%/%m
    n0 <- m * n1
    i =  sort(sample(n,n0))    
    i <- sort.list(x)[i]
    xsp2 <- array(x[i], c(m, n1))
    xt2 <- array(y1[i], c(m, n1))
   if (sym) xt2 <- abs(xt2) 
   zz <-f.csort(xt2)
   if (flag) 
        xq2 <- zz[round(qi * m), ]
   else xq2 <- apply(xt2, 2, quantile,qi)
    xp2 <- f.cmean(xsp2)
    if(!sym) { 
        xmed <- zz[round(m/2),]
        xq2  = t(t(xq2)-xmed)
        ymed = predict(smooth.spline(xp2,xmed,df=dg),x)$y
        y1   = y1-ymed
        } else { xmed<- rep(0,ncol(zz));ymed= rep(0,n) } 
tt = function(xq,qq) {
       xxtp <- smooth.spline(xp2,xq,df=dg)
       w = predict(xxtp,x)$y
       kc = quantile(y1/w,if(qq>0.5) qq else 1-qq)       
       w=predict(xxtp,x)$y*kc+ymed
       as.matrix(predict(smooth.spline(x,w),x0)$y)
}
vv = function(xq,qq) {
       xxtp <- smooth.spline(xp2,xq+xmed,df=dg)
       w = f.smdecreasing(xxtp,x,decreasing=down)
       kc = quantile((y1)/(w-ymed),if(qq>0.5) qq else 1-qq)       
       zz=(w-ymed)*kc+ymed
       w= zz+ quantile(-zz+y1+ymed,qq)
        as.matrix(predict(smooth.spline(x,w),x0)$y) 
}
if(type == "none") {
 if(length(qi) == 1) {xtp <- tt(xq2,qi)} else {
 xtp <- tt(c(xq2[1,]),qi[1]); for(i in 2:length(qi))xtp <- cbind(xtp,tt(c(xq2[i,]),qi[i]))
    }    } else { if(type=="inc") down=F
                  else if(type=="dec") down=T
    if(length(qi) == 1) {xtp <- vv(xq2,qi)} else {
       xtp <- vv(c(xq2[1,]),qi[1]); for(i in 2:length(qi))xtp <- cbind(xtp,vv(c(xq2[i,]),qi[i]))    }
   }
   if (logtran){xtp=exp(xtp); x0 = exp(x0); y0= exp(y0)}
if(plot) { 
   plot(x0,y0,pch=".",xlab="Sd",ylab="|T|")
   par(cex=0.5)
   npc=16; ccc=5
   if (!is.null(hqi)) { i2 <- y0 > xtp[,length(qi)] 
          points(x0[i2],y0[i2],col=ccc,pch=npc) }
   if (!is.null(lqi)) { i2 <- y0 < xtp[,1] 
          points(x0[i2],y0[i2],col=ccc,pch=npc) }
   if (sym) { i2 <- y0 < -xtp[,length(qi)] 
          points(x0[i2],y0[i2],col=ccc,pch=npc) }
  par(cex=1)
   matlines(x0[i2 <- sort.list(x0)],xtp[i2,],col= 3,lty = 1)
 }
  if(sym) matlines(x0[i2], -xtp[i2,], col= 3,lty = 1)
   dimnames(xtp) <-list(dimnames(xtp)[[1]], paste("Curve",qi,sep=""))
   cbind(T = c(y0),xtp,Sp=x0)
}

