f.smdecreasing <-
function(z,w,decreasing=T) {
# z output of smooth.spline with x component sorted.
# The y component of z must be non increasing, if not the 
#    function willmake it non-increasing
# Extrapolations are linear
x <- z$x
n <- length(x)
if( n < 20) return(z$y)
if(decreasing) y <- z$y else y <- (-z$y)
rx <- range(x)
rw <- range(w)
while( any (diff(y) >0) ) y <- pmax(y,y[c(2:n,n)])
i1 <- (w < rx[1])
i2 <- (w > rx[2])
i <- !(i1|i2)
w1 <- w
if(any(i)) w1[i] <- approx( x,y,w[i])$y
if(any(i1)) { 
        m1 <- lsfit(x[1:20],y[1:20])$coef[2]
        w1[i1] <- approx( c(rw[1],x[1]),c(y[1]-m1*(x[1]-rw[1]),y[1]),w[i1])$y
}
if(any(i2)) { 
        m2 <- lsfit(x[n-0:19],y[n-0:19])$coef[2]
        w1[i2] <- approx( c(x[n],rw[2]),c(y[n],y[n]-m2*(x[n]-rw[2])),w[i2])$y
}
if (decreasing) w1 else -w1
}

