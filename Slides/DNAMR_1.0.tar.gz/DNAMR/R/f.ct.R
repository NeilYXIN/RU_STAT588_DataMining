f.ct <-
function (x, y, qi = c(0.95,0.99), bsz = 200, plotenv=F,tol=10^(-10))
{
    x <- f.toarray(x)
    y <- f.toarray(y)
    xsp <- f.rsd(cbind(x, y))
    isp = !is.na(xsp) & xsp > tol
    xx = x[isp,]
    yy = y[isp,]
    xsp = f.rsp(xx, yy)
    nr <- nrow(xx)
    dd <- dim(xx)
    dy <- dim(yy)
    xt <- f.rtt(xx, yy)
#
xspp <- xsp
u = cbind(xx[abs(xt)< 1,],yy[abs(xt)< 1,])
u = (u-f.rmean(u))/f.rsd(u)
for(l in 1:20) {
xsp0 <- xspp
xsps <- sample(xsp0, rep = F)
x1 <- x2 <- NULL
for (i in 1:10) {
        x1 <- rbind(x1, array(sample(u), dd) * xsps)
        x2 <- rbind(x2, array(sample(u), dy) * xsps)
    }
xsp1 <- f.rsp(x1, x2)
m = ncol(x1)
x1 <- (x1 - f.rmean(x1))/xsp1/sqrt((m-1)/m)
y1 <- (x2 - f.rmean(x2))/xsp1/sqrt((m-1)/m)

xsps <- sort(xsp1)[(1:nr) * 10 - 5]
sxps <- sort(xsp)
sxps0 <- sort(xsp0)
    # this is the inverse computation.   Ft F^(-1) Fh
xspp <- f.smdecreasing(smooth.spline(xsps, sxps), sxps0, F)
}
#
    xsps <- sample(xspp, rep = F)
    xnn1 <- xnn2 <- NULL
    for (i in 2:(bsz%/%50)) {
        xnn1 <- rbind(xnn1, array(sample(u), dim(xx)) * xsps)
        xnn2 <- rbind(xnn2, array(sample(u), dim(yy)) * xsps)
    }
    xt1 <- f.rtt(xnn1, xnn2)
    xsp1 <- f.rsp(xnn1, xnn2)
    out = f.env(xsp1,abs(xt1),xsp,abs(xt),lqi=NULL,hqi=qi,type="none",sym=F,logtran=T,plot=plotenv)
    if(all(isp)) return(out) 
        res = array(0,c(nrow(x),ncol(out)), dimnames=list(rownames(x),colnames(out)))
        res[isp,] = out
   res
}

