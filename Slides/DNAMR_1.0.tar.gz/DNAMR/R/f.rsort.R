f.rsort <-
function(x) f.csort(t(x))

