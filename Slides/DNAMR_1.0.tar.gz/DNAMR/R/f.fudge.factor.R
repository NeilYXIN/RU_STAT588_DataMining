f.fudge.factor <-
function(x1,x2,tol = (10^(-10)) )  {
# x1 and x2 are two array with the same number of rows. No missing values are allowed.
  xsp <- f.rsd(cbind(x1,x2))
  isp =  !is.na(xsp)  &  xsp>tol 
  if(!all(isp)) { x1 = x1[isp,]; x2 = x2[isp,]}
  xt <- f.rtt(x1,x2)
  xsp <- f.rssp(x1,x2)
  qq <- quantile(xsp,(0:100)/100)
  aa <- quantile(xsp,(0:20)/20)
  gr <-as.numeric(cut(xsp, breaks=qq, left.include=T,include.lowest=F) )
  gr[is.na(gr)] <- 100
  ugr <- unique(gr)
  to <- matrix(0,length(aa),length(ugr))
  mx <- f.rmean(x1)-f.rmean(x2)
  sp <- f.rssp(x1,x2)
  for(i in 1:length(ugr)) {
     k <- gr==ugr[i]
     to[,i] <- apply(mx[k]/outer(sp[k],aa,"+"),2,f.mad)  
  }
  too <- apply(to,1,f.cv)
  aa[sort.list(too)[1]]
}

