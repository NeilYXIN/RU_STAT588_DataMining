f.ctcmu <-
function (x,y, qi = c(0.95,0.99),bsz= 200) {
  mu = f.rmean(cbind(x,y))
  mui = sort.list(mu)
  n=nrow(x)
  bszl=min(200,n%/%5)
  bn = 5*bszl
  k = length(qi)+2
  k1 = 1:k
  bk = 1:bszl
  nq = (n -bn)%/%bszl
  jj=matrix(NA,n,5*k,dimnames=list(rownames(x),NULL)) 
  for(i in 0:nq) {
  j = mui[bszl*i + 1:bn]
  if(i ==nq) j = mui[(bszl*i + 1):n]
  temp =f.ct(x[j,],y[j,],qi,bsz)
  for(l in 0:4) jj[j[l*bszl+bk],(4-l)*k+k1] = temp[l*bszl+bk,]
  }
i= 1+ (0:4)*k
z = apply(jj[,i],1,max,na.rm=T)
for(j in 1:(k-2)) z = cbind(z,
apply(jj[,i+j],1,function(x){ x=x[!is.na(x)]; n=length(x); mean(x[(n+ 1:2)/2]) }))
   colnames(z) <- c("T", paste("Curve",qi,sep=""))
cbind(z,  Sp=apply(jj[,i+k-1],1,max,na.rm=T) )
}

