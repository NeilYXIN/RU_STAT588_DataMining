f.rmean.na <-
function(x,n=ncol(x),na.rm=T) {
      ik <- rep(1,n)
      if(na.rm) {
        i <- is.na(x)
        ii <- c((!i)%*%ik)
        x[i ] <- 0
        return( c(x%*%ik)/ii )
      } else   return( c(x%*%ik)/n) 
}

