f.genes <-
function(x,gg,p=100,n=20) {
par(mar=c(2,1,1,1))
if(sum(par()$mfrow)<=2) par(mfrow=c(2,2))
x.F <- f.F(x,gg) 
x <-  x[sort.list(x.F[,2]),][1:p,]
i  <-rep(1:0,c(n,p-n)) 
x1=x[i==1,]
while(T) {
s=rep(-10^10,p)
for(j in (1:p)[!i]) { u <- f.pca(rbind(x1,x[j,]))$scores[,1:2]
s[j]= f.rsq(t(u),gg)
}
i[ii <- sort.list(-s)[1]] <- 1
x1 <- x[i==1,]
u <- f.pca(x1)$scores[,1:2]
u[,1] <- sign(u[1,1])*u[,1]
u[,2] <- sign(u[1,2])*u[,2]
plot(u,col=rep(unique(gg),table(gg)),pch=16,main=paste("Ngenes=",sum(i)))
plot(x[ii,],type='l', col=ii)
txt <- readline("Enter <Ret> to increase the n.of genes, 'q' to quit: ")
#if(txt == '-') i <- i-1 else i<-i+1
#if(i < 2) i <- 2
if(txt== 'q') break
}
}

