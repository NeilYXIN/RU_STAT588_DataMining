f.pam <-
function(x,y) {
	n <- nrow(x)
	p <- ncol(x)
	u <- unique(y)
	k <- length(u)
	mk <- sqrt(1/c(table(y)) + 1/n)
	mx0 <- f.rmean(x)
	mxi <- array(NA,c(n,k))
	xx <- x
	for(i in 1:k) { 
    		mxi[,i] <- f.rmean(x[,y==u[i]])
    		xx[,y==u[i]] <- xx[,y==u[i]]-mxi[,i]
	}
	dimnames(mxi)= list( dimnames(x)[[1]],u)
	sxi0 <- c( (xx^2)%*% rep(1,ncol(xx)))/(p-k)
	s0 <- median(sxi0)
	ssxi0 <- t(mk * t(array(sxi0,c(n,k)) +s0) )
	d0 <- (mxi - mx0)/ssxi0; q <- 20
	delta <- seq(0,max(d0),length=q)
	res <- array( NA, c(p,q))
	for(j in 1:p) { 
        	mk <- sqrt(1/c(table(y[-j]))+ 1/(n-1))
        	mx <- f.rmean(x[,-j])
        	mxi[,y[j]] <- f.rmean(x[,-j][,y[-j]==y[j]])
        	xx[,y==y[j]] <- x[,y==y[j]]-mxi[,y[j]]
        	sxi <- c( (xx[,-j]^2)%*% rep(1,p-1))/(p-k-1)
        	s0 <- median(sxi)
        	ssxi <- t(mk * t(array(sxi,c(n,k)) +s0) )
        	d <- (mxi - mx)/ssxi
    	for(i in 1:q) { 
        	dp <- sign(d)* pmax( abs(d) - delta[i], 0)
        	mxip <- mx + ssxi*dp
        	res[j,i]<-u[sort.list(f.cmean((mxip-x[,j])^2))[1]] 
        }
        mxi[,y[j]] <- f.rmean(x[,y==y[j]])
        xx[,y==y[j]] <- x[,y==y[j]]-mxi[,y[j]]
	}
	wmax <- max(w <- f.cmean(res==y))
	j  <- max((1:length(w))[w==wmax])
	dp <- sign(d0)*pmax(abs(d0)-delta[j],0)
	mxip = mxip <- mx0 + ssxi0*dp
       res =NULL; for(i in 1:p) res[i]<-u[sort.list(f.cmean((mxip-x[,i])^2))[1]] 
	genes <- dimnames(x)[[1]][(i<-f.rmean(dp^2))>0]
	list(class=res,genes=genes[sort.list(-i[i>0])], 
             PctCorrect=mean(res==y),Delta=delta[j],GroupMeans=mxip,GeneWeights=dp)
}

