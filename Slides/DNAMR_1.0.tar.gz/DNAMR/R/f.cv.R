f.cv <-
function(x) {
 num = sqrt(var(x))
 den = mean(x)
 den[num ==0] = 1
 num/den
 }

