f.rmedian.na <-
function(x) {
 n <- nrow(x)
 p <- ncol(x)
 xm <- rep(NA, n)
 nax <- is.na(x)
 nai <- c(nax %*% rep(1,p))
 x <- t(x)
 for(i in unique(nai)) {
    j <- nai ==i
    xi <- c(x[,j])
    xi <- array(xi[!is.na(xi)],c(p-i,sum(j)))
    xm[j] <- f.cmedian(xi)
} 
xm
}

