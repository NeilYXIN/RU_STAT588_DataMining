f.tar0 <-
function(a,b,z,gg) f.tar1(c(a,b),z,gg)

