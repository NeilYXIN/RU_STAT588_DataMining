f.cmedian <-
function(x) { 
 n  <- nrow(x)
 p  <- ncol(x)
 rx <- range(x)
 z  <- (x - rx[1])/(rx[2]-rx[1])*0.99
 k <- rep(1:p,rep(n,p))
 z  <- sort( z + k)
 dim(z) <- dim(x)
 z0 <- if( 2*(n%/%2) == n) (z[n/2,] + z[n/2+1,])/2 else z[(n+1)/2,]
 (z0-1:p)/0.99*(rx[2]-rx[1])+rx[1]
}

