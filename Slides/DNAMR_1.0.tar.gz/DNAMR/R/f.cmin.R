f.cmin <-
function (x) 
{
    n <- nrow(x)
    p <- ncol(x)
    rx <- range(x)
    z <- (x - rx[1])/(rx[2] - rx[1]) * 0.99
    k <- rep(1:p, rep(n, p))
    z <- sort.list(z + k)
    dim(z) <- dim(x)
    z[1,] - n*(0:(p-1))
}

