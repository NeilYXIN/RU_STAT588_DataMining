f.rsq <-
function(x,gr) {
   xm <-f.rmean(x)
sum( t((f.cmat(x,gr) - xm)^2)* c(table(gr)))/sum((x-xm)^2)
}

