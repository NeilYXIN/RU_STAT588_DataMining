f.rssp <-
function(x1,x2) f.rsp(x1,x2)*sqrt(1/ncol(x1) +1/ncol(x2))

