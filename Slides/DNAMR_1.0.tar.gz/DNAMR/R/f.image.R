f.image <-
function(X,gem=F) {
# Function to graph a concordance map. 
# gem= F (default)  X= Correlation matrix
# gem= T   X= Gene expression matrix (or any data matrix)
    if (gem) X <- f.concor(X)
# SAVE OLD GRAPHICS CONFIGURATION
    opar <- par(mar=c(2,2,3,2),mgp=c(1.5,0.5,0))
# SETUP THE LAYOUT
    mm <- array(c(1,2),dim=2)
    nf <- layout(mm,4,c(5,1),TRUE) 
    r <- range(X); 
    n <- nrow(X)
    xx<- 1:n
    U <- seq(length=100,from=r[1],to=r[2])
# DRAW IMAGE (OR INSERT HERE YOUR IMAGE CODE)
    par(mar=c(1,2,5,2),mgp=c(1.5,0.7,0))
    image(x=xx,y=xx,z=t(X[n:1,]),axes=F,xlab="",ylab="")
    box()
    nn= names(data.frame(y))
    axis(3,labels=nn,at=xx); 
    axis(2,labels=rev(nn),at=xx); 
# DRAW THE SCALE
    par(mar=c(3,2,1,2),mgp=c(1.5,0.7,0))
    image(x=U,z=array(U,c(100,1)),xlab="" ,axes=F)
    box();axis(1) 
# RESTORE OLD GRAPHICS CONFIGURATION
    par(mfrow=c(1,1)); par(opar)    
}

