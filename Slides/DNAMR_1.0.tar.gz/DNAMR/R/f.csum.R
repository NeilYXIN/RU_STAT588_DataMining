f.csum <-
function(x) c(rep(1,nrow(x))%*%x)

