f.rmest <-
function(y, mu, s, k, method = "bisquare", iter = 1) {
# This function calculates the M-estimator of location for the 
# rows of a matrix "y".  
# mu and s are the initial estimates of location and scale. By default 
# they are set to 0 and 1.
# method: "bisquare" m-estimator as default and "huber" m-estimator is optional.
# k = tuning parameter. As a default is 5 for the "bisquare" method and 2 for
# huber's method.
#  iter:  is the number of iterations. Iter =1 is a one step m-estimator. 
    method <- substring(method, 1, 1)
    if(missing(k))
        if(method == "h") k <- 2
        else k <- 5
    if(missing(mu))
        mu <- apply(y, 1, median, na.rm = T)
    if(missing(s))
        s <- apply(y, 1, mad, na.rm = T) 
    y1 <- c(y)
    kk <- dim(y)
    id <- rep(1:kk[1], kk[2])
    n <- length(y)
    s[s <= 0] <- min(s[s > 0], na.rm = T)
    s0 <- rep(s, kk[2])
    for(i in 1:iter) {
        mu0 <- rep(mu, kk[2])
        if(method == "h") {
            mu0 <- rep(mu, kk[2])
            yy <- pmin(pmax(mu0 - k * s0, y1), mu0 + k * s0)
            mu1 <- rmean(array(yy, dim = kk))
        }
        else {
            yy1 <- (y1 - mu0)/s0
            w <- (k^2 - yy1^2)^2
            w[is.na(w)] <- 0
            w[abs(yy1) > k] <- 0
            w <- array(w, dim = kk)
            w <- w/c(w %*% rep(1, kk[2]))
            y[is.na(y)] <- 0
            mu1 <- c((y * w) %*% rep(1, kk[2]))
        }
        mu <- mu1
    }
    mu
}

