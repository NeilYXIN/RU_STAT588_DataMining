f.F <-
function(x,g) { 
   tk <- c(table(g));   k <- length(tk) 
   i= sort.list(g); x =x[,i]; g=g[i]
   ttk <- cbind(rep(tk,k),0) 
   ttk[1+(k+1)*(0:(k-1)),2] <- 1 
   cm <- t(t(x%*%array(rep(ttk[,2],ttk[,1]),c(length(g),k)))/tk) 
   xm <- f.rmean(x)  
   tss <- (x - xm)^2 %*% rep(1,n <- ncol(x)) 
   bss <- (cm - xm)^2 %*%c(table(g))  
   F <-  bss/(k-1) /(tss-bss)*(n-k) 
   mfc <-  apply(cm,1,range); mfc <-mfc[2,]-mfc[1,] 
   data.frame(F=F, pval= 1-pf(F,k-1,n-k),LogFoldChange=mfc ) 
}

