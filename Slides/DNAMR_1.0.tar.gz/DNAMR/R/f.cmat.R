f.cmat <-
function(x,gr) {
  x <- x[,sort.list(gr)]
  tk <- c(table(gr))
  p <- length(tk)
  ttk <- cbind(rep(tk,p),0)
  ttk[1+(p+1)*(0:(p-1)),2] <- 1
  z <- array(rep(ttk[,2],ttk[,1]),c(length(gr),p))
  t(t(x%*%z)/tk)
}

