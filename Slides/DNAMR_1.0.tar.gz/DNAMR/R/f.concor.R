f.concor <-
function(X,Y) {
# Calculates the concordance correlation matrix
# X:  Matrix or vector
# Y:  Optional vector or matrix
  if (!missing(Y)) X <- cbind(X,Y)
  d <- ncol(X)
  n <- nrow(X)
  tx <- t(X)
  nam <- names(data.frame(X))
  xm <-  f.rmean(tx)
  xv <- f.rvar(tx) 
  xsd <- sqrt(xv) 
  tx <- (tx -xm)
  z <- array(1,c(d,d),dimnames=list(nam,nam))
  for(i in 2:d) for ( j in 1:(i-1) )
    z[i,j] <- 2*sum(tx[i,]*tx[j,])/n / (xv[i]+xv[j] + (xm[i]-xm[j])^2 ) 
  z + t(z) - 1
}

