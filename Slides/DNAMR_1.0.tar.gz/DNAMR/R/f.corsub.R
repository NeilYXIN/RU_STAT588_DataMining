f.corsub <-
function(X,maxn,nb=20,maxc=0.97,mx=10) {
 maxX <- apply(X,1,max) 
if(missing(maxn))  kk <- maxX > (max(X)/mx) else
                  kk <- sort.list(-maxX)< (nrow(X) +maxn )/2
        X <- X[kk,] 
        n <- nrow(X)
        nn <- n%/%nb
        jj <- rep(0,n)
        for(i in 1:nn) {
                ii  <- (i-1)*nb + 1:nb  
                tt  <-cor(t(X[ii,]),t(X[-ii,]) )
                tt1 <- cor(t(X[ii,]))
                diag(tt1) <- 0
                tt  <- abs(cbind(tt,tt1))
                jj[ii] <- apply(tt,1,max)
        }
        if (n < nn*nb) { 
                ii <- (nn*nb+1):n
                tt1 <- cor(t(X[ii,])); diag(tt1) <- 0 
                jj[ii]<- apply(abs(cbind(cor(t(X[ii,]),t(X[-ii,])),tt1)),1,max)
        }
if(missing(maxn))  kk[kk] <- (jj > maxc) else
                  kk[kk] <- sort.list(-jj)<= maxn
kk
}

