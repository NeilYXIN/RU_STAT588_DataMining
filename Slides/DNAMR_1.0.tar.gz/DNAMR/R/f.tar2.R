f.tar2 <-
function(a,z,gg) {
x = log(z-a)
p = ncol(x)
n = nrow(x)
tgr = c(table(gg))
ngr = length(tgr)
i = rep(rep(0:1,ngr)[-1],c(rbind(p,tgr))[-1])
dim(i) =c(p,ngr)
im = t(t(i)/tgr)
xm = x%*%im
xr = x - xm%*%t(i)
r1 = f.cv( sqrt((xs<-f.rsum(xr^2))/(p-ngr)))
r2 = mean(f.rsum(xr^3)^2/xs^3,na.rm=T)
xs = sqrt(xr^2%*%i) 
sum(r1,r2,mean(diag(cor(xm,xs))^2))
}

