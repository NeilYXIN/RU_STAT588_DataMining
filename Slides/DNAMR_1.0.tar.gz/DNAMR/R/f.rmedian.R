f.rmedian <-
function(x) f.cmedian(t(x))

