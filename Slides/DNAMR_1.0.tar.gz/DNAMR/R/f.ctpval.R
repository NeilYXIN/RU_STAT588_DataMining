f.ctpval <-
function(x.ct,nch=6, tol = 10^(-10)) {
out = x.ct[,1,drop=F]
isp = !is.na(c(out)) & abs(c(out)) > tol
xx = x.ct[isp,]
out[!isp,]=1
p <- ncol(xx) 
pr = 2:(p-1)
x <- log(xx[,pr])
n = nrow(xx)
p2 <- p-2
u <- as.numeric( substring(dimnames(x.ct)[[2]][pr],nch))
y = log(-log(1-u))
xm = c(x%*%rep(1,p2)/p2)
x2 = (x-xm)^2 %*%rep(1,p2)
xy = (x-xm)%*%(y-mean(y))
b = xy/x2
m = mean(y)-b*xm
out[isp,] = exp(-exp(m+b*log(abs(xx[,1]))))
out
}

