f.rmean <-
function(x,n=ncol(x)) c(x%*%rep(1,n))/n

