f.samperm <-
function(x,y,con, ns=100) { 
   n <- (n1 <- ncol(x)) + (n2 <- ncol(y))

   if( (kk <- f.comb(c(n1,n2))) < ns) { 
        ns <- kk; 
        ii <- f.permtwo(n,n1)  
      } 
   else if(kk < 20000) 
        ii <- f.permtwo(n,n1)[sample(kk,ns),] 
   else  ii <- t(sapply(rep(n,ns),sample))  
  ## Perform permutation argument
  xx <- cbind( x, y )

  to <- f.permmean(xx,ii,n1,con)       
  f.csort(to) 
}

