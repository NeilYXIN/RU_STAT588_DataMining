f.comb <-
function(g) 
   round(exp(sum(log(1:sum(g)))-sum(sapply(g,function(x)sum(log(1:x))))))

