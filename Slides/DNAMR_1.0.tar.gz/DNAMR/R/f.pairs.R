f.pairs <-
function(X) 
## Graph the scatterplot matrix of X with a smoothing curve
##  
pairs(X,panel= function(x,y) { 
		points(x,y,pch='.');
 		abline(0,1,col=2,lwd=1.5);
		lines(lowess(x,y,f=0.2),col=3,lwd=1.5)
		}
	)

