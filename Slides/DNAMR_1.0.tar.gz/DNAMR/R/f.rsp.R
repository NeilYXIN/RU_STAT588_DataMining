f.rsp <-
function(x1, x2) sqrt((f.rvar(x1) + f.rvar(x2))/2)

