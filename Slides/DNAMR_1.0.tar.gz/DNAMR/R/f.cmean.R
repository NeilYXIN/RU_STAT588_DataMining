f.cmean <-
function(x,n=nrow(x)) c(rep(1,n)%*%x)/n

