f.rsum <-
function(x) c(x%*%rep(1,ncol(x)))

