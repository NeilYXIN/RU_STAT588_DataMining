f.narm <-
function(x) {x[is.na(x)] <- F; x}

