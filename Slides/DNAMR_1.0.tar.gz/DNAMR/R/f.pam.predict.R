f.pam.predict <-
function(x, obj) {
 res =NULL
 u = unique(obj[[1]])
 for(i in 1:ncol(x)) 
    res[i]<-u[sort.list(f.cmean((obj[[5]]-x[,i])^2))[1]]
res
}

