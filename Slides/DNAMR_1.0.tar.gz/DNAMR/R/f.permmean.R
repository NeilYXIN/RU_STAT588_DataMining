f.permmean <-
function(xx,ii,k=4,con=0.01) {
  dx <- dim(xx)
  ns = nrow(ii)
  n = ns %/%20
  nr = ns - n*20
  zt <- NULL
  if(n>0)
    for(i in 0:(n-1)) { 
      jj <- c(ii[i*20+1:20,] ) 
      z <- xx[, jj] 
      dim(z) <- dx*c(20,1) 
      zt <- c(zt,f.rtt(z[,1:k],z[,-(1:k)],con))
    }
  if(nr>0)  { 
      jj <- c(ii[ns-nr + 1:nr ,] ) 
      z <- xx[, jj] 
      dim(z) <- dx*c(nr,1) 
      zt <- c(zt,f.rtt(z[,1:k],z[,-(1:k)],con))
  }
dim(zt) <- c( dx[1],ns)
zt
}

