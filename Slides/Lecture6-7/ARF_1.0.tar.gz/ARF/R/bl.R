bl <-
function(k) sapply(k, function(n) paste(rep(" ",n),collapse=""))
