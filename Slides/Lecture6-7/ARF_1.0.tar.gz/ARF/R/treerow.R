treerow <-
function(x,y,nm,con=1,delta=0) {
        n = length(x)
        z = NULL
        for(i in 1:n) { 
                if(nm[i] =="L") z[i] = x[i]-y[i]/2 - (if(i<n) y[i+1]/2 else 0) - 0.01 else
                if(nm[i] =="M") z[i] = x[i] else
                if(nm[i] =="R") z[i] = x[i]+y[i]/2 + (if(i>1) y[i-1]/2 else 0) + 0.01   
        }

dz =diff(z)
dy = (y[-1]+y[-n])/2 - delta
j = dz < dy
if(any(j)) { for(i in (1:(n-1))[j]) {
                z[1:i] = z[1:i] - (dy[i]-dz[i])/2 - 0.0005*con
                z[-(1:i)] = z[-(1:i)] + (dy[i]-dz[i])/2 + 0.0005*con
}}      
if ( z[1] - y[1]/2 < -.5) { if( z[n] -z[1] +y[n]/2 +y[1]/2<2 ) z = z -z[1]+y[1]/2-0.5 else
if(any(!j)) { for(i in (1:(n-1))[!j]) {
                z[1:i] = z[1:i] - (dy[i]-dz[i])/2 
                z[-(1:i)] = z[-(1:i)] + (dy[i]-dz[i])/2
                        if( z[n] -z[1] +y[n]/2 +y[1]/2 < 2 ) break
                                }
}
}
if ( z[n] + y[n]/2 > 1.5 & z[n] -z[1] +y[n]/2 +y[1]/2<2 ) z = z -( z[n]+y[n]/2-1.5) 
z
}
