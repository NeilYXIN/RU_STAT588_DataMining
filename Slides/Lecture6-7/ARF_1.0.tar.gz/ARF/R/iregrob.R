iregrob <-
function (x, y, gr, nc = 16, fr = 1, out = 1, const = 1,Tstat=fF){
   ii = !is.na(x) & !is.na(y)
    x0 = x[ii]
    y0 = y[ii]; gr = gr[ii]
    ii = sort.list(x0)
    y0 = y0[ii]
    x0 = x0[ii]; gr = gr[ii]
    my = sapply(split(y0,gr),function(y) c(unlist(hubers(y)),length(y)))
    n  = length(x0)
    sp = sqrt(sum(my[2,]^2*(my[3,]-1))/(n-2))
    md = my[1,2]-my[1,1]
    inc = -(1:nc)
    z  = NULL
    tx = table(x0); nxu = length(tx)
    xu = cumsum(tx)
    i  = sum(xu < nc/2) 
    tx = c(sum(tx[1:(i+1)]), if( (i+2)<=length(tx)) tx[(i+2):nxu] else NULL) 
    tx = rev(tx); nxu= length(tx)
    xu = cumsum(tx)
    i  = sum(xu < nc/2) 
    tx = rev(c(sum(tx[1:(i+1)]), if( (i+2)<=length(tx)) tx[(i+2):nxu] else NULL)) 
    xu = cumsum(tx)
    nxu = length(xu)
    xl = c(1, xu[-nxu] + 1)
    cy1 = cy2 = n1 = NULL
    for( i in 1:nxu ) {
                   ii =  xl[i]:xu[i]; jj= gr[ii] 
                    cy1[i] = sum(y0[ii[jj==1]]) 
                    cy2[i] = sum(y0[ii[jj==0]]) 
                    n1[i] = sum(jj)
                    }

   n2 =  as.vector(- n1 + tx)

    if (n <= nc) 
      return(c(Min = min(x), Lower = min(x), Upper = max(x),
         Max = max(x), "%Interval" = 100, Crit = 0, Sf = 0,
             rep(0,3),md))
  for (i in 1:nxu) {
        j   = i:nxu
        nj1 = cumsum(n1[j])
        nj2 = cumsum(n2[j])
        if(all(njj<-((nj <- pmin(nj1,nj2)) < nc/2 ))) break
        j = j[!njj]; nj1 =nj1[!njj]; nj2 =nj2[!njj]
        w1 = NULL
        for(l in j) { 
                ii =  xl[i]:xu[l]; jj= gr[ii] ; yu=y0[ii];
                w1= c(w1,hubers(yu[jj==1])$mu-hubers(yu[jj==0])$mu)
                }
#        ii  = (nj < nc/2) * max(y0 + 10^9)
#        w1  = w1 - md 
        w2  = cbind(rep(x0[xl[i]], length(j)), x0[xu[j]],w1-md)
        w3  = (w2[, 3])/(sp * sqrt(1/nj1+1/nj2))
        jj  = sort.list(-w3)[1:min(out,length(j))]
        w2  = w2[jj,,drop=F]; w3 = w3[jj]
        w4  = (nj1[jj]+nj2[jj])/n
        jjj = log(pmin(w4,fr)*n)/log(n*fr)
        jjj = w3 + const*jjj
        z   = rbind(z,cbind(w2,w4,jjj,w3))
        jj0 = sort.list(-z[,6])[1:out]
        z   = z[jj0,,drop=F]
    }
if(is.null(z))       return(c(Min = min(x), Lower = min(x), Upper = max(x),
         Max = max(x), "%Interval" = 100, Crit = 0, Sf = 0,
            rep(0,3),md))
zz = matrix(0,ncol=6,nrow=nrow(z))
for(i in 1:nrow(zz)) {
    ii1 = x0 < z[i,1]; ii2 = x0 > z[i,2];  ii3 = !(ii1 | ii2)
    zz[i,] = c(sum(ii1),mean(y0[ii1&gr])-mean(y0[ii1&(!gr)]),sum(ii2),mean(y0[ii2&gr])-mean(y0[ii2&(!gr)])
,sum(ii3),mean(y0[ii3&gr])-mean(y0[ii3&(!gr)]))
    }
    cbind(Min = rep(x0[1], out), Lower = z[, 1], Upper = z[, 2], 
        Max = rep(x0[n], out), "%Interval" = z[, 4] * 100, T =z[,6], 
 Sf = z[,6] > qt(0.95, z[, 4] * 2*n - 1),zz)
}
