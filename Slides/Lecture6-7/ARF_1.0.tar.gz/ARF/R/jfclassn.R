jfclassn <-
function(x, y, nc0=20, fr=1, out=1, const=1) {
   temp= NULL
   tt = NULL
   for( i in 1:ncol(y))  if(min(table(y[,i]))>5) {
             temp <- rbind(temp,jclassn(x, y[,i], nc0, fr, out, const)) ;
             tt = c(tt,i)
   }

   if(is.null(temp)) return(NULL)
   temp = temp[k<- sort.list(-temp[,2])[1],,drop=F]
    j <- !is.na(match(as.character(x),strsplit(rownames(temp),",")[[1]]))
   cbind(tt[k],0,0,0,temp[,-4,drop=F], P=matrix(apply(y[ j,,drop=F],2,mean),nrow=1)) 
}
