pltab <-
function(v1,font=1, col=1, delta=1/55) {
if((k1<-length(font)) <(k2 <-length(v1)) ) font[(k1+1):k2] <- font[k1]
if((k1<-length(col)) < k2 ) col[(k1+1):k2] <- col[k1]
plot(0:1,0:1,axes=F,type="n", xlab="",ylab="")
for( i in 1:length(v1)) text(0.5, 1.02 - (i-1)*delta,  v1[i],font=font[i],col=col[i])
}
