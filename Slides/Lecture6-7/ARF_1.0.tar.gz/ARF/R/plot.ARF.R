plot.ARF <-
function(z,size=c("l","m","s")[1],ttype=c("s","m","l")[1],
       sizehead=0.7,header="",plot=T) { 
########################################################################
# z: is a data structure, output from the function f.arff.
# size: size of the graph (small, medium or large) 
# ttype: Type of tree (small, medium or large)
########################################################################
if(size=="l")  con = 1. else if(size=="m") con = 0.75 else if(size=="s") con=0.5 else con=size
fl = function(y1,y2,x1,x2=x1,col=1)  lines(c(x1,x2),c(y1,y2),col=col) 
fsub = function(str) list( substring(str,1,nchar(str)-1),
                 substring(str,nchar(str),nchar(str)))
     w= z$data
     u= z$tree
     resp = z$resp

if(resp=="fact"){
#  u = cbind(u,hresp=as.numeric(z[[7]])) 
hresp=as.numeric(factor(z[[7]])) 
names(hresp) = rownames(u) }

# if(resp=="bin") w[2] = w[2]
if(is.na(w[1]>=0 & w[2]>=0))
   return(cat("Error. Tree strucure is not properly formed\n"))
#windows(10,6,rescale="fit")
ww = data.frame(Var="",z[[6]][1],0,0,t(w[-1]),w[1],"NS","FU")
px = 0.5; py = 1
nk = length(w)-2
#browser()
ww = array(tbox(px,py,ww,con=con*1.08,re=resp,plot=F),c(1,4))
u = f.select(u,w,resp,z[[7]],ttype=ttype)
if(size=="l" & nrow(u)>10)  con = 0.8 
if(size=="s" & nrow(u)>40)  con = 0.35
if(size=="s" & nrow(u)<=25)  con = 0.6
if(!(nrow(u)) > 0) return(cat("Error. No tree nodes found. Tree strucure is not properly formed \n"))  
un = dimnames(u)[[1]]
nun = nchar(un)
u = u[i<-( un!="NA"),]; un = un[i]; nun=nun[i]
unl = list()
nlev = max(nun)
for(i in 1:nlev) { unl[[i]] = sort(unique(substring(un,1,i))) 
    unl[[i]] = unl[[i]][ nchar(unl[[i]]) ==i] }
wid = (ww[3]-ww[1])*1.15
xll1 = NULL
for(i in 1:nlev) {
     unli = unl[[i]]
     u1 = NULL
     nli = length(unli)
     for(j in 1:nli)
         u1[j]= any(un ==unli[j])
     delta= (i <4)*0.02*con*(4-i)
     l1 = (wid * u1 + con*0.015 * (1-u1))+0.03 *con +  delta
     pstr = fsub(unli)
     nstr = pstr[[2]]; pstr=pstr[[1]]
     l0 = NULL
     if(pstr[1] == "") { l0=rep(1,nli)} else
     for(j in 1:nli)
         l0[j] = (1:length(px))[names(px) ==pstr[j]]                 
     lx= px[l0]
     xl1 = treerow(lx,l1,nstr,con,delta)
#browser()
#     xll1[[i]] = xl1
     for(j in 1:nli) {
         ii = l0[j]
         px[unli[j]] = xl1[j]
         py[unli[j]] = ww[ii,2] - 0.057*con
         uin = if(any(un ==unli[j]))  u[unli[j],] else rep(NA,8)
         ww = rbind(ww,tbox(px[unli[j]],py[unli[j]],uin,con=con*1.08,re=resp,plot=F))
     }
}
par(mar=c(0,0,0,0),cex=0.75*con)
xlim = range(ww[,c(1,3)])
 xlim = xlim + (xlim[2]-xlim[1])*c(0,0.1)
ylim = range(ww[,c(2,4)])
ylim = ylim + (ylim[2]-ylim[1])*c(-0.2,0.2)

plot(xlim,ylim,type="n",axes=F,xlab="",ylab="")
par(cex=sizehead) 

for (i in 1:length(header)) text( mean(xlim),ylim[2]- (i-1)*(ylim[2]-ylim[1])/40,header[i])
par(cex=0.75*con)
ww = data.frame(Var=" "," ",0,0,t(w[-1]),w[1],"NS","FU")
px = 0.5; py = 1
nk = length(w)-2
ww = array(tbox(px,py,ww,con=con*1.08,re=resp),c(1,4))
if(resp=="fact") { 
    pp = par()$cex;  par(cex=max(pp,0.6)); 
         legend(1.2,1.02, tw<-names(z[[2]])[-1], col=as.numeric(factor(tw))+2,lwd=2)         
        par(cex=pp)           }
for(i in 1:nlev) {
     unli = unl[[i]]
     u1 = NULL
     nli = length(unli)
     for(j in 1:nli)
         u1[j]= any(un ==unli[j])
     delta= (i <4)*0.01*con*(4-i)
     l1 = (wid * u1 + con*0.015 * (1-u1))+0.03 *con +  delta
     pstr = fsub(unli)
     nstr = pstr[[2]]; pstr=pstr[[1]]
     l0 = NULL
     if(pstr[1] == "") { l0=rep(1,nli)} else
     for(j in 1:nli)
         l0[j] = (1:length(px))[names(px) ==pstr[j]]                 
     lx= px[l0]
     xl1 = treerow(lx,l1,nstr,con,delta)
     for(j in 1:nli) {
         ii = l0[j]
         px[unli[j]] = xl1[j]
         py[unli[j]] = ww[ii,2] - 0.057*con

         col = if(resp=="fact") hresp[unli[j]]+2 else 1
         fl(ww[ii,2],ww[ii,2]-0.04*con,px[ii],px[unli[j]],col=col)
         uin = if(any(un ==unli[j]))  u[unli[j],] else rep(NA,8)
         ww = rbind(ww,tbox(px[unli[j]],py[unli[j]],uin,con=con*1.08,re=resp))
     }
}
par(cex=1, mar=c(2,1,2,1))
invisible()
}
