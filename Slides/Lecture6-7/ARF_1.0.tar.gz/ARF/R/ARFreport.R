ARFreport <-
function(u, file = "report.pdf",nlines=36,sizehead=0.7) {

pdf(file=file,width=10, height=7.5,fonts=c("NewCenturySchoolbook","Courier"))

uu = sort(unique(u[[1]][[1]]))
u2 = is.na( match( u[[6]],uu))
u2 = u[[6]][u2]
u3 = names(u[[2]])
if( u[[3]]=="fact") u3[-1] = paste("P(",u3[-1],")",sep="")
resp = if(u[[5]][[2]][[1]] =="~") u[[5]][[2]][[2]] else u[[5]][3]
str1= c( paste("RESPONSE VARIABLE = ",resp,sep=""),
    paste("PREDICTORS = ",paste(uu,collapse=", "),sep=""),
if( length(u2)>0) paste("NOT USED=",paste(u2,collapse=", ")) else "",
    paste(u3, round(u[[2]],3) , sep= " = ", collapse= " "))
n0 = nchar(str1)

if(n0[2] + n0[3] < 110) {
    str1[2] = paste(str1[2],str1[3],sep= ". "); 
    str1[3:4]=c(str1[4],"")} else str1=c(str1,"")

 if( max(nchar(str1)) > 110) sizehead=sizehead*0.7 
if(any(u[[1]]$Sf =="S")) pl(u,ttype="s",size="l",sizehead=sizehead,header=str1)
pl(u,ttype="l",size="s",sizehead=sizehead,header=str1)

v = u[[1]]

par(family="Courier",cex=sizehead)

n = nrow(v)
delta = sizehead*1.1/(nlines+1)
n1 =  n %/% nlines

col = (v$Sf=="S")+1

if(n1 > 0) for(j in 1:n1) pltab(c(str1,gentab(v[(j-1)*nlines+1:nlines,])),delta=delta,font=c(2,2,2,2,2,1),col=c(1,1,1,1,1,col[(j-1)*nlines+1:nlines]))
pltab(c(str1,gentab(v[(n1*nlines):n,])),delta=delta,font=c(2,2,2,2,2,1),col=c(1,1,1,1,1,col[(n1*nlines):n]))

if(any(u[[1]]$Sf =="S")) {
	v = f.subsets(u)
	for(i in 1:ncol(v)) v[,i] = as.character(v[,i])
        strs=gentab2(f.toarray(v))


while(T) {
	pltab(c(str1,strs[1:nlines]),delta=delta,font=c(2,2,2,2,2,1))
     if(length(strs)> nlines) strs=strs[-(1:nlines)] else break  }

}
dev.off()
}
