mrpart <-
function (x, y, treat, minsplit = 30, minbucket = 12, cp = 0.01) 
{
 # x:        Matrix or data.frame with p columns and n rows.
#           The columns represent predictor variables whereas
#           The rows represent the observations.
# y:        Response vector of zeroes or ones.
# varlist:  List of vars specifying the first splits
# highresp: List of vars specifying the first splits
# Predict:  If TRUE will calculate predicted values for the observations.
# minn:     Minimum bucket size before split.
# nlayers:  Maximum number of layers of the tree.
# nc:       20
# fr:       Fraction of the data at which the penalty becomes constant.
# const:    Penalty weight. Default is 1 but larger numbers would
#           benefit larger subsets.
    call = match.call()
    if (class(x) == "formula") {
        vars = all.vars(x)
        y = data[[vars[1]]]
        if (any(vars[-1] == ".")) 
            x = data[, names(data) != vars[1]]
        else x = data[, vars[-1]]
    }
    alist= list( 
      eval=
        function (y, wt, parms) 
        {
          z = uncodey(y, parms)
          y = z$y
          n = length(y)
          trt = z$trt
          i1 = trt == 1
          i2 = trt == 0
          wt1 = wt2 = wt
          wt1[i2] = 0
          wt2[i1] = 0
          n1 = max(sum(wt1), 0.1)
          n2 = max(sum(wt2), 0.1)
          if (is.factor(y)) {
            if (any(is.na(y) | is.na(trt))) 
              print("NA's")
            tt = table(y, trt)
            rss = sum(abs(jj <- (tt[, 1]/(0.1 + sum(tt[, 1])) - tt[, 
                                                                   2]/(0.1 + sum(tt[, 2])))) * (tt[, 1] + tt[, 2]))
            return(list(label = sum(abs(jj)), deviance = sum(tt) - 
                          rss))
          }
          y = y - sum(y * wt)/sum(wt)
          y1 = y2 = y
          y1[i2] = 0
          y2[i1] = 0
          wmean1 = sum(y1 * wt1)/sum(wt1)
          wmean2 = sum(y2 * wt2)/sum(wt2)
          rss = sum(wt1 * (y1 - wmean1)^2) + sum(wt2 * (y2 - wmean2)^2)
          list(label = (wmean1 - wmean2)/sqrt(1/n1 + 1/n2), deviance = rss)
        }
      
      ,split=
        function (y, wt, x, parms, continuous) 
        {
          rsum = function(x) c(x %*% rep(1, ncol(x)))
          z = uncodey(y, parms)
          y = z$y
          n = length(y)
          trt = z$trt
          i1 = trt == 1
          i2 = trt == 0
          wt1 = wt2 = wt
          wt1[i2] = 0
          wt2[i1] = 0
          if (is.factor(y)) {
            wt1[wt1 > 0] = 1
            wt2[wt2 > 0] = 1
            if (sum(wt1 + wt2) < n) 
              cat("error\n")
            nlev = nlevels(y)
            lev = levels(y)
            if (continuous) {
              tt = table(y, trt)
              tbp1 = tbp2 = tbq1 = tbq2 = NULL
              ry = rev(y)
              rwt1 = rev(wt1)
              rwt2 = rev(wt2)
              for (i in 1:nlev) {
                tbp1 = cbind(tbp1, cumsum((y == lev[i]) * wt1))
                tbp2 = cbind(tbp2, cumsum((y == lev[i]) * wt2))
                tbq1 = cbind(tbq1, cumsum((ry == lev[i]) * rwt1))
                tbq2 = cbind(tbq2, cumsum((ry == lev[i]) * rwt2))
              }
              ind1 = c(tbp1 %*% rep(1, nlev)) + 0.1
              ind2 = c(tbp2 %*% rep(1, nlev)) + 0.1
              rind1 = c(tbq1 %*% rep(1, nlev)) + 0.1
              rind2 = c(tbq2 %*% rep(1, nlev)) + 0.1
              mt = (tbp1/ind1 - tbp2/ind2)[-n, , drop = F] - (tbq1/rind1 - 
                                                                tbq2/rind2)[(n - 1):1, , drop = F]
              tb = (1/ind1 + 1/ind2)[-n] + (1/rind1 + 1/rind2)[(n - 
                                                                  1):1]
              gg = c(abs(mt/sqrt(tb)) %*% rep(1, nlev))
              if (any(is.na(y) | is.na(x) | is.na(c(gg, 1)))) 
                print("NA")
              return(list(goodness = gg, direction = -sign(mt[, 
                                                              1])))
            }
            else {
              ux <- sort(unique(x))
              nxlev = length(ux)
              x1 = factor(x)
              tt1 = table(x1[i1], y[i1])
              tt2 = table(x1[i2], y[i2])
              nt1 = rsum(tt1)
              nt2 = rsum(tt2)
              nt1[nt1 == 0] = 0.1
              nt2[nt2 == 0] = 0.1
              tt0 = (tt1/nt1 - tt2/nt2) * sqrt(nt1 + nt2)
              j = sort.list(tt0[, sort.list(-apply(tt0, 2, var))[1]])
              rj = rev(j)
              ct1 = apply(tt1[j, ], 2, cumsum)
              ct2 = apply(tt2[j, ], 2, cumsum)
              qt1 = apply(tt1[rj, ], 2, cumsum)
              qt2 = apply(tt2[rj, ], 2, cumsum)
              rsct1 = rsum(ct1)
              rsct1[rsct1 == 0] = 0.1
              rsct2 = rsum(ct2)
              rsct2[rsct2 == 0] = 0.1
              rsqt1 = rsum(qt1)
              rsqt1[rsqt1 == 0] = 0.1
              rsqt2 = rsum(qt2)
              rsqt2[rsqt2 == 0] = 0.1
              cnt1 = ct1/rsct1
              cnt2 = ct2/rsct2
              qnt2 = qt2/rsqt2
              qnt1 = qt1/rsqt1
              j1 = 1:(nxlev - 1)
              j2 = rev(j1)
              res = rsum(abs((cnt1 - cnt2)[j1, , drop = F] - (qnt1 - 
                                                                qnt2)[j2, , drop = F])/sqrt(1/rsct1[j1] + 1/rsct2[j1] + 
                                                                                              1/rsqt1[j2] + 1/rsqt2[j2]))
              browser()
              return(list(goodness = res, direction = ux[j]))
            }
          }
          y = y - sum(y * wt)/sum(wt)
          y1 = y2 = y
          y1[i2] = 0
          y2[i1] = 0
          if (continuous) {
            temp1 <- cumsum(y1 * wt1)[-n]
            left.wt1 <- cumsum(wt1)[-n]
            right.wt1 <- sum(wt1) - left.wt1
            lmean1 <- temp1/left.wt1
            rmean1 <- (sum(wt1 * y1) - temp1)/right.wt1
            lmean1[left.wt1 == 0] = 0
            rmean1[right.wt1 == 0] = 0
            temp2 <- cumsum(y2 * wt2)[-n]
            left.wt2 <- cumsum(wt2)[-n]
            right.wt2 <- sum(wt2) - left.wt2
            lmean2 <- temp2/left.wt2
            rmean2 <- (sum(wt2 * y2) - temp2)/right.wt2
            lmean2[left.wt2 == 0] = 0
            rmean2[right.wt2 == 0] = 0
            left.wt1[left.wt1 == 0] = 1/25
            left.wt2[left.wt2 == 0] = 1/25
            right.wt1[right.wt1 == 0] = 1/25
            right.wt2[right.wt2 == 0] = 1/25
            yy = y - sum(y * wt)/sum(wt)
            nn = sqrt(1/left.wt1 + 1/left.wt2 + 1/right.wt1 + 1/right.wt2)
            goodness = abs(lmean1 - lmean2 - rmean1 + rmean2)/sqrt(sum(wt * 
                                                                         yy^2))/nn
            list(goodness = goodness, direction = sign(lmean1 - lmean2 - 
                                                         rmean1 + rmean2))
          }
          else {
            ux <- sort(unique(x))
            wtsum1 <- tapply(wt1, x, sum)
            ysum1 <- tapply(y1 * wt1, x, sum)
            wtsum2 <- tapply(wt2, x, sum)
            ysum2 <- tapply(y2 * wt2, x, sum)
            means <- ysum1/wtsum1 - ysum2/wtsum2
            ord <- order(means)
            n <- length(ord)
            temp1 <- cumsum(ysum1[ord])[-n]
            left.wt1 <- cumsum(wtsum1[ord])[-n]
            right.wt1 <- sum(wt1) - left.wt1
            lmean1 <- temp1/left.wt1
            rmean1 <- (sum(wt1 * y1) - temp1)/right.wt1
            lmean1[left.wt1 == 0] = 0
            rmean1[right.wt1 == 0] = 0
            temp2 <- cumsum(ysum2[ord])[-n]
            left.wt2 <- cumsum(wtsum2[ord])[-n]
            right.wt2 <- sum(wt2) - left.wt2
            lmean2 <- temp2/left.wt2
            rmean2 <- (sum(wt2 * y2) - temp2)/right.wt2
            lmean2[left.wt2 == 0] = 0
            rmean2[right.wt2 == 0] = 0
            yy = y - sum(y * wt)/sum(wt)
            nn = sqrt(1/left.wt1 + 1/left.wt2 + 1/right.wt1 + 1/right.wt2)
            goodness = abs(lmean1 - lmean2 - rmean1 + rmean2)/sqrt(sum(wt * 
                                                                         yy^2))/nn
            list(goodness = goodness, direction = ux[ord])
          }
        }
      
      ,init=
        function (y, offset, parms, wt) 
        {
          if (!is.null(offset)) 
            y <- y - offset
          list(y = y, parms = parms, numresp = 1, numy = 1, summary = function(yval, 
                                                                               dev, wt, ylevel, digits) {
            paste("  mean=", format(signif(yval, digits)), ", MSE=", 
                  format(signif(dev/wt, digits)), sep = "")
          })
        }
      
      ,text=
        function (yval, dev, wt, ylevel, digits, n, use.n) 
        {
          if (use.n) {
            paste(format(yval, digits = digits), "\nn=", n, sep = "")
          }
          else {
            paste(format(yval, digits = digits))
          }
        }
      
      ,print=function (yval, ylevel, digits) 
      {
        if (is.null(ylevel)) 
          temp <- as.character(yval[, 1])
        else temp <- ylevel[yval[, 1]]
        nclass <- (ncol(yval) - 1)/2
        if (nclass < 5) {
          yprob <- format(yval[, 1 + nclass + 1:nclass], digits = digits, 
                          nsmall = digits)
        }
        else yprob <- format(yval[, 1 + nclass + 1:nclass], digits = 2)
        if (is.null(dim(yprob))) 
          yprob <- matrix(yprob, ncol = length(yprob))
        temp <- paste(temp, " (", yprob[, 1], sep = "")
        for (i in 2:ncol(yprob)) temp <- paste(temp, yprob[, i], 
                                               sep = " ")
        temp <- paste(temp, ")", sep = "")
        temp
      } )
    
    
    
    n <- nrow(x)  
  if (!is.data.frame(x)) 
    x = data.frame(x)
  yy = codey(y, treat)
  w = rpart(yy$y ~ ., data = x, method = alist, parms = yy$parms, 
            control = rpart.control(minsplit = minsplit, minbucket = minbucket, 
                                    cp = cp))
  if (is.numeric(y)) {
    w$functions = w$functions[-6]
    return(w)
  }
  w[[1]]$yval2 = recal(w, y, treat)
  w$functions$text = tmp6
  w
}
