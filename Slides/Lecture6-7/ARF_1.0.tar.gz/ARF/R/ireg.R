ireg <-
function(x, y, nc = 20, fr = 0.5, out = 5, const = 1)
{
	ii <- !is.na(x) & !is.na(y)
	x <- x[ii]
	y <- y[ii]
	ii <- sort.list(x)
	y <- y[ii]
	x <- x[ii]
        my = mean(y)
        sy = sqrt(var(y))
	xx <- (0:100)/100
	yy <- quantile(y, xx)
	inc <-  - (1:nc)
	n <- length(x)
	z <- NULL
        tx = table(x)
        xu = cumsum(tx)
        nxu = length(xu)
        xl = c(1,xu[-nxu]+1)
        cy = NULL
	for(i in 1:nxu) cy[i] = sum(y[xl[i]:xu[i]]) 
	if(n <= nc) 
		return(c(Min = min(x), Lower = min(x), Upper = max(x), Max = 
			max(x), "%Interval" = 100, Crit = 0,Sf=0,Response = mean(y)
			))
	for(i in 1:nxu) {
		j <- i:nxu
		nj <- cumsum(tx[j])
                if(all(nj < nc)) break
		ii = (nj < nc)*max(y+10^6)	
		w1 <- cumsum(cy[j])/nj - ii  
		jj <- sort.list(-w1)[1:min(out,nxu)]
		w2 <- cbind(rep(x[xl[i]], length(jj)), x[xu[j][jj]], w1[jj])	
#browser()
#		w3 <- approx(yy, xx, w2[, 3])$y
		w3 <- (w2[,3] - my)/sy*sqrt(nj[jj])
		w4 <- nj[jj]/n
		
		jjj <- log(pmin(w4, fr) * n)/log(n * fr)
		jjj <- w3 + const * jjj	#	jjj[w4 < frmin] <- 0
		z <- rbind(z, cbind(w2, w4, jjj))
		jj0 <- sort.list( - z[, 5])[1:out]
		z <- z[jj0,  , drop = F]
	}
	cbind(Min = rep(x[1], out), Lower = z[, 1], Upper = z[, 2], Max = rep(x[
		n], out), "%Interval" = z[, 4] * 100, Crit= z[, 5], 
		Sf =z[,3]>qt(.975,z[,4]*n-1),Response = z[, 3] )
}
