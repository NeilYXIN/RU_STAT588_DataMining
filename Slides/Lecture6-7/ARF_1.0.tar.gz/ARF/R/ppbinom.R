ppbinom <-
function(x, n, p)
(x/n - p)/sqrt((p * (1 - p))/n)
