jnode <-
function(x, y, catpred = rep(F, ncol(x)), rtype = "bin", nc0 = 20, 
    fr = 1, out = 1, const = 1) 
{
    p <- ncol(x)
    n <- nrow(x)
    nn <- names(x)
    if (rtype == "bin" & min(table(y)) <= 5) 
        return(NULL)
    tempest <- NULL
    u <- dimnames(x)[[2]]
    if (is.null(u)) 
        u = paste("x", 1:ncol(x), sep = "")
    if ((nc <- sum(catpred)) > 0) {
        xc = x[, catpred, drop = F]
        nc = ncol(xc)
        for (j in 1:nc) {
            ii <- !is.na(xc[, j])
            xx <- xc[ii, j]
            yy = if (rtype == "fact") y[ii,] else y[ii]
            if (length(table(xx)) > 1) {
                if (rtype == "bin" & min(table(yy))>5) 
                    temp <- data.frame(0,0,0,0,jclassn(xx,yy,nc0,fr,out,const))
                  else temp <- NULL
                if (rtype == "cont") 
                  temp <- jrclassn(xx, yy, nc0, fr, out, const)
                if (rtype == "fact") 
                  temp <- jfclassn(xx, yy, nc0, fr, out, const)
               if(is.null(row.names(temp))) { 
                            u[j] = j 
                            tempest <- rbind(tempest, c(j, rep(0,8)))
                } else {
                tempest <- rbind(tempest, c(j, temp))
                u[j] = row.names(temp) }
            }
            else u[j] <- "z3456"
        }
    }
    if ((mc <- sum(!catpred)) > 0) {
        xc = x[, !catpred, drop = F]
        for (j in 1:mc) {
            ii <- !is.na(xc[, j])
            xx <- xc[ii, j]
            yy = if (rtype == "fact") y[ii,] else y[ii]
            if (length(table(xx)) > 1) {
                if (rtype == "bin" & min(table(yy)) > 5) 
                  temp <- jcartn(xx, yy, nc0, fr, out, const)
                else temp <- NULL
                if (rtype == "cont") 
                  temp <- ireg(xx, yy, nc0, fr, out, const)
                if (rtype == "fact") 
                  temp <- jfcartn(xx, yy, nc0, fr, out, const)
                tempest <- rbind(tempest, c(nc + j, temp))
            }
            else u[j + nc] <- "z3456"
        }
    }
    if (!is.null(tempest)) 
        row.names(tempest) <- u[u != "z3456"]
    f.toarray(tempest)
}
