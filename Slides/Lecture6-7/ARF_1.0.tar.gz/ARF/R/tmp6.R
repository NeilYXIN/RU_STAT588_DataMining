tmp6 <- function (yval, dev, wt, ylevel, digits, n, use.n) 
{
  nclass <- (ncol(yval) - 1)/2
  group <- yval[, 1]
  counts <- yval[, 1 + (1:nclass)]
  if (!is.null(ylevel)) 
    group <- ylevel[group]
  temp1 <- format(counts, digits)
  if (nclass > 1) {
    temp1 <- apply(matrix(temp1, ncol = nclass), 1, paste, 
                   collapse = "/")
  }
  if (use.n) {
    out <- paste(format(group, justify = "left"), "\n", temp1, 
                 sep = "")
  }
  else {
    out <- format(group, justify = "left")
  }
  return(out)
}
