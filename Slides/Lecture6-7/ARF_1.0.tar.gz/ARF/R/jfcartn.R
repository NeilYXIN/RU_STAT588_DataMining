jfcartn <-
function(x, y, nc0=20, fr=1, out=1, const=1) {
   temp= NULL
   for( i in 1:ncol(y)) if(max(table(y[,i]))< (length(x)-5))   
           { temp1 = jcartn(x, y[,i], nc0, fr, out, const)[-1]
             if(is.null(temp1)) temp = rbind(temp,rep(c(i,0),c(1,7))) else
             temp <- rbind(temp,c(i,temp1))
          } else temp = rbind(temp,rep(c(i,0),c(1,7)))
   if(is.null(temp)) return(rep(-1,7+ncol(y)) )
#cat("c\n")
#browser()
   row.names(temp) = paste(row.names(temp), colnames(y),sep="-")

   temp = temp[sort.list(-temp[,6])[1],,drop=F]
   c(temp[-8], apply(y[ x <=temp[3] & x>=temp[2],,drop=F],2,mean))
}
