pos <-
function(x)
{
        x <- sort(x)
        z <- unique(x)
        m <- length(z)
        n <- 1:length(x)
        out <- cbind(z * 0, 0)
        for(i in 1:m)
                out[i,  ] <- range(n[x == z[i]])
        out
}
