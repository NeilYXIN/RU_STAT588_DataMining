uncodey = function (z, pa) 
{
  if (is.character(pa[1])) {
    z = pa[-1][z]
    zz = matrix(unlist(strsplit(z, pa[1])), ncol = 2, byrow = T)
    return(list(y = factor(zz[, 1]), trt = as.numeric(zz[, 
                                                         2])))
  }
  else {
    gr = floor(z)
    gru = sort(unique(gr))
    for (i in 1:length(gru)) z[gr == gru[i]] = (z[gr == gru[i]] - 
                                                  gru[i]) * pa[2 * gru[i] + 3] + pa[2 * gru[i] + 2]
    return(list(y = z, trt = gr))
  }
}
