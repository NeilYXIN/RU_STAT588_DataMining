f.toarray <-
function(x) array(unlist(x) , dim(x), dimnames(x))
