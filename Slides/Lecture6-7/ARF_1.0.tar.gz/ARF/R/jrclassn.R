jrclassn <-
function(x, y, nc = 20, fr = 1, out = 2, const = 1)
{
# x vector of numbers
# y vector of binaries
# nc = minimum length of subset
# fr = penalty related to fraction
# out =  number subsets outputed
# const = penalty constant
        ii <- !is.na(x) & !is.na(y)
        x <- x[ii]
        y <- y[ii]
        n <- length(x)
    my = mean(y) 
    sy = sqrt(var(y)) 
        nd = round(nc/2)

                 u = cbind(Min = sort(x)[1], Lower = sort(x)[1], Upper = sort(x)[n], Max
                         = sort(x)[n], "%Interval"
                         = 100, Crit = 0, Sig = 0, "Ave" = my)
                 row.names(u) <- as.character(unique(x)[1]); 
                 if(n <= nc  | length(unique(x))==1) {return(u) }
        z = split(y,x)
        zm = t(sapply(z,function(x) c(sum(x),length(x))))
    
        zm = zm[ ii <- sort.list(-zm[,1]/zm[,2]),]
        zm = cbind(zm,cumsum(zm[,1]),cumsum(zm[,2]))
        zm = cbind(zm,zm[,3]/zm[,4])
        zm = zm[zm[,4] >=nc & (n-zm[,4])>=nd ,,drop=F]
        if(length(zm)<5) return(u)
       
        jjj0 <- (zm[,5]-my)/sy*sqrt(zm[,4])
        jjj <- jjj0 + (const * log(pmin(zm[,4]/n, fr) * n))/log(n * fr)
        nam = names(z)[ii]
        if(length(nam)>1) for(i in 2:length(nam)) nam[i] = paste(nam[i-1],",",nam[i],sep="")
                jj <- sort.list( - jjj)[1:out]
        u = cbind(0,0,0,0, "%Interval" = zm[jj,4]/n * 100, Crit = 
                jjj[jj], Sig = jjj0[jj] > qt(0.975,zm[jj,4]-1),"Mean"=zm[jj,5])
       row.names(u) <- nam[jj]; 
        u
}
