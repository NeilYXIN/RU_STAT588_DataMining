jclassn <-
function(x, y, nc = 20, fr = 1, out = 2, const = 1)
{
# x vector of categories
# y vector of binaries
# nc = minimum length of subset
# fr = penalty related to fraction
# out =  number subsets outputed
# const = penalty constant
        nd = round(nc/2)
        ii <- !is.na(x) & !is.na(y)
        x <- x[ii]
        y <- y[ii]
        ppp <- mean(y)
        n <- length(x)
        z = table(x,y)
#        if(n <= nc | sum(y)<5 | sum(y)>n-5 | min(x) == max(x)| ncol(z) < 2)
            ret0 = cbind("%Interval" = 100, Crit = 0, Sig = 0,"%Success" = (sum(y)/n) * 100 )
            dimnames(ret0) = list("0",colnames(ret0))
        if(ncol(z)<2) return(ret0)
    z = z[ ii<-sort.list(-z[,2]/(z[,1]+z[,2])),]
    z = cbind(z,cumsum(z[,2]),cumsum(z[,1]+z[,2]))
    z = cbind(z,z[,3]/z[,4]) 
    z = z[z[,4] >=nc & (n-z[,4])>=nd ,,drop=F]

        if(length(z)<5) return(ret0)
                jjj0 <- ppbinom(z[,3],z[,4] , ppp)
                jjj <- jjj0 + (const * log(pmin(z[,4]/n, fr) * n))/log(n * fr)
         nam = dimnames(z)[[1]]
       if(length(nam)>1)  for(i in 2:length(nam)) nam[i] = paste(nam[i-1],",",nam[i],sep="")
                jj <- sort.list( - jjj)[1:out]
        
        u = cbind( "%Interval" = z[jj,4]/n * 100, Crit = 
                jjj[jj], Sig = 1 * (jjj[jj] > t95(ppp, n)),"%Success" = z[jj,5])
    row.names(u) <- nam[jj]; u
}
