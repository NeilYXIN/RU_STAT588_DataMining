jcartn <-
function(x, y, nc = 20, fr = 1, out = 5, const = 1)
{
# x vector of numbers
# y vector of binaries
# nc = minimum length of subset
# fr = penalty related to fraction
# out =  number subsets outputed
# const = penalty constant
        nd = round(nc/2)
        ii <- !is.na(x) & !is.na(y)
        x <- x[ii]
        y <- y[ii]
        ii <- sort.list(x)
        y <- y[ii]
        x <- x[ii]
        ppp <- mean(y)
        n <- length(x)
        if(is.null(x)) x = 0
        if(n <= nc | sum(y) < 5 | sum(y)> n-5 | min(x) == max(x)) return(NULL)
#                return(cbind(Min = min(x), Lower = min(x), Upper = max(x), Max
#                         = max(x), "%Success" = (sum(y)/n), "%Interval"
#                         = 100, Crit = 0, Sig = 0))
        yp <- y
        yy <- diff(y)
        yl <- (2:n)[yy == 1]
        yu <- (2:n)[yy == -1] - 1
        if(y[1] == 1)
                yl <- c(1, yl)
        if(y[n] == 1)
                yu <- c(yu, n)
        if(any(table(x) > 1)) {
                xul <- pos(x) # generate indices of the interval for repeats
                yu <- fixuseq(x, yu, xul[, 2])
                yl <- fixlseq(x, yl, xul[, 1])
                nl <- length(yl)
                jj0 <- mean(y[yl[1]:yu[1]])
                tt <- rep(T, nl + 1)
                if(any(is.na(c(yl, yu))))
                        browser()
                for(i in 2:nl) {
                        jj1 <- mean(y[yl[i]:yu[i]], na.rm = T)
                        if((jj0 == 0 & jj1 == 0) | (jj0 == 1 & jj1 == 1))
                                tt[i] <- F
                        jj0 <- jj1
                }
                yl <- yl[tt[1:nl]]
                yu <- yu[tt[-1]]
        }
#		 iu = yl > nd & yu<= n-nd
#        yl=yl[iu]; yu=yu[iu]
        nl <- length(yl)
        yd <- NULL
#       if(any(is.na(c(yl, yu)))) browser()
        for(i in 1:nl)
                yd[i] <- sum(y[yl[i]:yu[i]], na.rm = T)
        if(any(is.na(yd)))
                browser()
        w1 <- w2 <- w3 <- w4 <- NULL
        jj <- 0
        for(i in 1:nl) {
                nn <- sum(yu < (yl[i]+nc)) + 1
                
                if(nn<=nl) {
                        w1 <- c(w1, rep(yl[i], nl - nn + 1))
                        w2 <- c(w2, yu[nn:nl])
                        t4 <- yu[nn:nl] - yl[i]
                        w3 <- c(w3,(cumsum(yd[nn:nl]) + (if(nn > i) sum(yd[i:(
                                nn - 1)]) else 0))/(t4 + 1))
                        w4 <- c(w4, (t4+1)/n)
			}}
         i11 <-cleanna((w1 ==1 | w1 > nd) & (w2==n | w2 <= n-nd) & ((w2-w1) >=nc))                
                if(!all(i11)) {
                        w1 <- w1[i11]
                        w2 <- w2[i11]
                        w3 <- w3[i11]
                        w4 <- w4[i11]
                }
         if(sum(i11) < 1) return(NULL)
                jjj0 <- ppbinom(w3 * n * w4 - 1, n * w4, ppp)
                jjj <- jjj0 + (const * log(pmin(w4, fr) * n))/log(n * fr)

                jj <- sort.list( - jjj)[1:out]
                w1 <- w1[jj]
                w2 <- w2[jj]
                w3 <- w3[jj]
                w4 <- w4[jj]
        if(is.null(w1)) return(NULL)
        cbind(Min = rep(x[1],out),Lower = x[w1], Upper = x[w2], Max = rep(x[n
                ],out),"%Interval" = round(w4*100,2), Crit = 
                jjj[jj], Sig = 1 * (jjj[jj] > t95(ppp, n)),"%Success"=round(w3,2))
}
