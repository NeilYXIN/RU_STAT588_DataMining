recal =function (w, y, trt)  {
  bin = function(x) if (x == 1) 
    1
  else x%%2 + bin(x%/%2) * 10
  whe = w$where
  wsp = w$splits
  tt0 = w[[1]]
  tt = as.numeric(rownames(tt0))
  m = nrow(tt0)
  jj = NULL
  for (i in 1:m) jj[i] = bin(tt[i])
  jj = as.character(jj)
  ypred2 = NULL
  for (i in 1:m) {
    j1 = jj[i] == substring(jj, 1, nchar(jj[i]))
    whe[!is.na(match(whe, (1:m)[j1]))]
    j2 = !is.na(match(whe, (1:13)[j1]))
    t3 = table(y[j2], trt[j2])
    t4 = t3[, 2]/sum(t3[, 2]) - t3[, 1]/sum(t3[, 1])
    ypred2 = rbind(ypred2, c(sort.list(-t4)[1], t3[, 1] + 
                               t3[, 2], t4))
  }
  ypred2
}
