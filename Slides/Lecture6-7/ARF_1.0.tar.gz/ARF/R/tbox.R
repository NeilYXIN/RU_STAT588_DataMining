tbox <-
function(x,y,u,plot=T,del=0.005,con=1,re="bin") {
  con2 = 0.075; con3 = 0.015
  if (is.na(u[3])) { 
        if(plot)        rect(x-.01*con,y-con2*con,x+0.01*con,y+con3*con)
        return(c(x-.01*con,y-con2*con,x+0.01*con,y+con3*con))   
  }
if(!is.na(u[length(u)-1]) & u[length(u)-1] == "S") col<-2 else col <-1
  un=length(u)-8
  namu = names(u)[5+0:un]
  u = c(as.character(u[[1]]),as.character(u[[2]]), as.character(c(round(u[6+un]),round(u[5+(0:un)],2))))

  if(re=="fact")  v = c(paste(u[1],u[2],sep=" \178 "),paste("n=",u[3],paste(" \177 ",namu[1],"=",u[4],sep=""),sep=""),
                  paste(namu[-1],u[4+1:un],sep="=",collapse=" \177 ") )
  if(re=="cont")
    v=c(u[1],u[2],paste("n=",u[3],";M=",u[4],sep="",collapse=""))
  if(re=="bin")
    v=c(u[1],u[2],paste("n=",u[3],";P=",u[4],sep="",collapse=""))

  un = 2*con*max(sapply(v,nchar))^0.95
  if(u[1] == " ") {con2=0.045;v=v[-1];ii=0:1} else ii=0:2
  if(plot) { 
        text(x,y-ii*0.03*con,v,col=col)
        rect(x-un*del,y-con2*con,x+un*del,y+con3*con,border=col)
        }
  return(c(x-un*del,y-con2*con,x+un*del,y+con3*con))
}
