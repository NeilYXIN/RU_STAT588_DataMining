cleanna <-
function(x) {x[is.na(x)] <- F;x }
