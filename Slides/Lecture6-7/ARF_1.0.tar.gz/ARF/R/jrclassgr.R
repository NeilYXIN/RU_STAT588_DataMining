jrclassgr <-
function (x, y,gr, nc = 10, fr = 1, out = 2, const = 1) 
{
    ii = !is.na(x) & !is.na(y)
    x  = x[ii]
    y  = y[ii]; gr=gr[ii]
    n  = length(x)
    gg = (sort(unique(gr)))
    my = sapply(split(y,gr),function(y0) c(mean(y0),var(y0),length(y0)))
    sp = sqrt(sum(my[2,]*(c(n-sum(gr),sum(gr))-1))/(n-2))
    md = my[1,2]-my[1,1]
  
    nd = round(nc/2)
    u  = cbind(0, 0, 0, 0, "%Interval" = 100, Crit = 0, Sig = 0,0,NA,0,NA,n, 
        Ave = md)
    row.names(u) <- as.character(unique(x)[1])
    if (n <= nc | length(unique(x)) == 1) {
        return(u)
    }
    ii = split(gr, x)
    z = split(y, x); zm = NULL; zz= list()

    for(j in 1:length(gg)) {
      for(l in 1:length(z)) zz[[l]] = z[[l]][ii[[l]]==gg[j]]
       zm = cbind( zm, t(sapply(zz, function(x) c(sum(x), length(x)))))
    }
        i0  = zm[,2] & zm[,4]
        zmm = zm[!i0,,drop=F]
        zm  = zm[i0,,drop=F] 
        zm  = zm[ii <- sort.list(zm[, 1]/zm[, 2]-zm[,3]/zm[,4]), ]
   if( nrow(zmm) > 0) ii = c(ii, nrow(zm)+1:nrow(zmm))
        zm  = rbind(zm,zmm)
    nam = c((names(z)[i0])[ii],names(z)[!i0])
zm = cbind( zm,apply(zm,2,cumsum))
zm=cbind(zm,-zm[,5]/zm[,6]+zm[,7]/zm[,8])
zm=cbind(zm,(zm[,9]-md)/(sp*sqrt(1/zm[,6]+1/zm[,8])))
zm = cbind(zm,t( zm[nrow(zm),5:8]-t(zm[,5:8])))
zm=cbind(zm,-zm[,11]/zm[,12]+zm[,13]/zm[,14])

    zm  = zm[pmin(zm[,6],zm[,8],zm[,12],zm[,14]) >= nd, , drop = F]
    if(length(zm) < 5) return(u)
    jjj0 = zm[,10] 
    jjj <- jjj0 + (const * log(pmin((zm[,6]+zm[,8])/n,fr)*n))/log(n*fr)
    if (length(nam) > 1) 
        for (i in 2:length(nam)) nam[i] = paste(nam[i - 1], ",", 
            nam[i], sep = "")
    jj <- sort.list(-jjj0)[1:out]
    u = cbind(0, 0, 0, 0, "%Interval" = (nn<-(zm[jj,6]+zm[jj,8]))/n * 100, T = jjj[jj], 
        Sig = jjj0[jj] > qt(0.975, zm[jj, 6]+zm[jj,8] - 2),zm[jj,12]+zm[jj,14],zm[jj,15],0,NA,nn,MeanDiff = zm[jj,9])
    row.names(u) <- nam[jj]
    u
}
