fixlseq <-
function(x, yl, xl)
{
        n <- length(x)
        yl <- sort(unique(c(yl, xl)))
        for(k in 1:(n+10)) {
                yl <- unique(yl)
                j <- x[yl[if(yl[1] == 1) -1]] == x[yl - 1]
                if(any(j))
                        yl[if(yl[1] == 1) -1][j] <- yl[if(yl[1] == 1) -1][j] - 
                                1
                else return(yl)
        }
}
