fixuseq <-
function(x, yu, xu)
{
        n <- length(x)
        yu <- sort(unique(c(yu, xu)))
        for(k in 1:(n+10)) {
                yu <- unique(yu)
                m <- length(yu)
                j <- x[yu[if(yu[m] == n)  - m]] == x[(yu + 1) %% (n + 1)]
                if(any(j))
                        yu[if(yu[m] == n)  - m][j] <- yu[if(yu[m] == n)  - m][j
                                ] + 1
                else return(yu)
        }
}
