gentab <-
function(v) {
	w = dimnames(v)[[2]]
	k = ncol(v)-8
	v1 = c(w[8+k],v[,8+k])
	nn=nchar(v1)
	v1 = paste(bl(max(nn)-nn),v1,sep="")

	for(i in k+(7:6)) {
		v1 = paste(c(w[i],v[,i]),v1,sep=" ")
		nn=nchar(v1)
		v1 = paste(bl(max(nn) -nn) , v1,sep="")
		}

	for(i in (k+5):3) {
		v2 = c(w[i],as.character(round(v[,i],3)) )
		nn=nchar(v2)
v2 = paste(v2,bl(max(nn) -nn),sep="")
v1 = paste(v2,v1,sep=" ")
}
for(i in 2:1) {
v1 = paste(c( w[i],v[,i]),v1,sep=" ")
nn=nchar(v1)
v1 = paste(bl(max(nn) -nn) , v1,sep="")
}

v2 = c(" ",dimnames(v)[[1]])
nn=nchar(v2)
v2 = paste(v2,bl(max(nn) -nn),sep="")
paste(v2,v1,sep=" ")
}
