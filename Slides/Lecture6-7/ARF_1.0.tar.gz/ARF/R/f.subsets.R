f.subsets <-
function(z,ttype=c("s","m","l")[1],exclude = F, arr=T, exit1=F) {
fl = function(y1,y2,x1,x2=x1)  lines(c(x1,x2),c(y1,y2))
fsub = function(str) list( substring(str,1,nchar(str)-1),
                     substring(str,nchar(str),nchar(str)))
w =      z$data
u = u0 = z$tree
resp =   z$resp
nk = if(resp == "fact") (ncol(u)-7) else 1

if(is.na(w[1]>=0 & w[2]>=0))
  return(cat("Error. Tree structure is not properly formed.\n"))

ww = data.frame(Var="","DATASET", w[2]*100, 0,0,w[1],"NS","FU")
px = 0.5; py = 1

u = f.select(u,w,resp,z[[7]],ttype=ttype)

if(!(nrow(u)) > 0) return(cat("Error. No tree nodes found. Tree strucure is not properly formed \n"))  
un = rownames(u)
nun = nchar(un)

if(exclude) {
 for(i in 2:length(un)) { 
  if(!any(paste(substring(un[i],1,nun[i]-2),"M",sep="")==un) | substring(un[i],nun[i]) !="M") un[i] <-"NA"} 
 u = u[i<-( un!="NA"),]; un = un[i]; nun=nun[i]
}

unl = list()
nu = length(un)
res = res0 =  NULL
resu = list()
for(i in 1:nu) if(!exclude | !any( paste(un[i],"M",sep="")==un)) {
  uu = NULL
  for(j in 1:nun[i]) 
	if(any(jj <-(substring(un[i],1,j)==dimnames(u0)[[1]])))
            uu = rbind(uu,c(u0[jj,1],u0[jj,2]))
	ii = 1:nrow(uu)
	names(ii) = uu[,1]
	uu = uu[rev(ii)[unique(uu[,1])],,drop=F]
	res = c(res,paste(uu[,1],"in",uu[,2],collapse=" & "))
	res0 = rbind(res0,unlist(u[i,c(5+0:nk)]))
resu[[i]] = uu        
}
if( exit1 ) return(resu)

res = data.frame(Subset=res,res0)
names(res)=c("Subset",names(u)[5+0:nk])
for(i in 1+1:nk ) res[,i]<- round(res[,i],3)
if(arr) {
z =strsplit(as.character(res[,1]), "&")
res0 = NULL

for(i in 1:length(z)) {
if( i >1) res0 = rbind(res0,0/0)
      res0 = rbind(res0,c(z[[i]][1],res[i,-1]))
      if( length(z[[i]]) > 1 ) for(j in 2:length(z[[i]])) res0 = rbind(res0,c( z[[i]][j], res[i,-1]*0/0))
    }

w = array(unlist(res0),dim(res0),dimnames(res0))
strpbl = function(x) if( substring(x,nchar(x)) == " ") strpbl(substring(x,1,nchar(x)-1)) else x 
w[,1] <- sapply (w[,1], strpbl)

w[w =="NaN" ] <- " "
w = data.frame(w)
nam = paste( "Subset", 1:nrow(res), sep=" ")
lab = rep( " ", nrow(w))
lab[ c( -1,diff( w[,1] == " ")) == -1 ] <- nam
w =data.frame( lab,w)
colnames(w)[1:2] <- c(" ", "SUBSET")
return(w)
} else (return(res))

}
