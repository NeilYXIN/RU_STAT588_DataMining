jnodegr <-
function (x, y,gr, catpred=rep(F,ncol(x)), rtype="bin", nc0=5, 
    fr = 1, out = 1, const = 1,robust=F) 
{
    p <- ncol(x)
    n <- nrow(x)
    nn <- names(x)
    if (rtype == "bin" & min(table(y)) <= 5) 
        return(NULL)
    tempest <- NULL
    u <- dimnames(x)[[2]]
    if (is.null(u)) 
        u = paste("x", 1:ncol(x), sep = "")
    if ((nc <- sum(catpred)) > 0) {
        xc = x[, catpred, drop = F]
        nc = ncol(xc)
        for (j in 1:nc) {
            ii <- !is.na(xc[, j])
            xx <- xc[ii, j]
            yy = if (rtype == "fact") y[ii,] else y[ii]
            if (length(table(xx)) > 1) {
                if (rtype == "bin" & min(table(yy)) > 5)
                  temp <- jrclassgr(xx, yy,gr, nc0, fr, out, const)
                  else temp <- NULL
                if (rtype == "cont") 
                  temp <- jrclassgr(xx, yy,gr, nc0, fr, out, const)
                if (rtype == "fact") 
                  temp <- jfclassgr(xx, yy, gr,nc0, fr, out, const)
               tempest <- rbind(tempest, c(j, temp))
                u[j] = row.names(temp)
            }
            else u[j] <- "z3456"
        }
    }
    if ((mc <- sum(!catpred)) > 0) {
        xc = x[, !catpred, drop = F]
        for (j in 1:mc) {
            ii <- !is.na(xc[, j])
            xx <- xc[ii, j]
            yy = if (rtype == "fact") 
                y[ii, ]
            else y[ii]
            if (length(table(xx)) > 1) {
                if (rtype == "bin" & min(table(yy)) > 5) {
                 temp <- if(robust) iregrob(xx, yy,gr,nc0,fr,out,const) else
                                    iregr(xx, yy,gr,nc0,fr,out,const) }
                else temp <- NULL
                if (rtype == "cont"){
                 temp <- if(robust) iregrob(xx, yy,gr,nc0,fr,out,const) else
                                    iregr(xx, yy,gr,nc0,fr,out,const) }
                if (rtype == "fact") 
                  temp <- jfcartn(xx, yy, nc0, fr, out, const)
                tempest <- rbind(tempest, c(nc + j, temp))
            }
            else u[j + nc] <- "z3456"
        }
    }
    if (!is.null(tempest)) 
        row.names(tempest) <- u[u != "z3456"]
    f.toarray(tempest)
}
