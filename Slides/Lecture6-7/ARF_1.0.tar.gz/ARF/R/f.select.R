f.select <-
function(u,w,resp,preds,ttype="s",minn=15) {
   if( resp=="fact") {   p = NULL
   preds = as.character(preds)
   for(i in 1:nrow(u)) p[i] = u[i,preds[i]]
   }
   if (ttype=="s") u[u$Sf =="S" & u$N >= minn & if(resp=="fact") p >= w[preds] else T ,]
   else if (ttype=="m") u[u$Sf =="S",]
   else u
}
