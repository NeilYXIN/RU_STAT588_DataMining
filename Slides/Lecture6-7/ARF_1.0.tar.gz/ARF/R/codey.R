codey =  function (y, gr) {
  gru = sort(unique(gr))
  agrep = function(x, pa = "_") {
    x = paste(x, col = "")
    pa0 = pa
    while (T) {
      if (length(grep(pa0, x)) == 0) 
        break
      else pa0 = paste(pa0, pa, sep = "")
    }
    pa0
  }
  if (is.numeric(y)) {
    yy = y
    params = length(gru)
    for (i in 1:length(gru)) {
      z = yy[gr == gru[i]]
      mi = min(z)
      params[2 * i + 0:1] = c(mi, (max(z) - mi) * 1.01)
      yy[gr == gru[i]] = (i - 1) + (yy[gr == gru[i]] - 
                                      params[2 * i])/params[2 * i + 1]
    }
  }
  else if (is.factor(y)) {
    params = agrep(gru, "_")
    yy = factor(paste(y, gr, sep = params))
    params = c(params, levels(yy))
  }
  list(y = yy, parms = params)
}
