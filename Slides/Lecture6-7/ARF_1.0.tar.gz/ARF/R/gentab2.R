gentab2 <-
function(v) {
w = dimnames(v)[[2]]
k = ncol(v)
v1 = c(w[k],v[,k])
nn=nchar(v1)
v1 = paste(bl(max(nn)-nn),v1,sep="")

for(i in (k-1):1) {
v1 = paste(c(w[i],v[,i]),v1,sep=" ")
nn=nchar(v1)
v1 = paste(bl(max(nn) -nn) , v1,sep="")
}
return(v1)
}
