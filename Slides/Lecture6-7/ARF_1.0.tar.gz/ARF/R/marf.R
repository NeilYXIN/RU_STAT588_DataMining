marf <-
function (x, y, gr, data = NULL, varlist = NULL, highresp = NULL, 
    predict = T, minbucket =30 , nlayers = 10, fr = 1, out = 1, const = 1,robust=F) 
{
    call = match.call()
    library(MASS)
    if (class(x) == "formula") {
        vars = all.vars(x)
        y = data[[vars[1]]]
        if (any(vars[-1] == ".")) 
            x = data[, names(data) != vars[1]]
        else x = data[, vars[-1]]
    }
    n <- nrow(x)
    if (!is.data.frame(x)) 
        x <- data.frame(x)
    catpred = sapply(x, function(z) if (length(unique(z))==2) T else
     if (is.numeric(z))    F    else T)
    yy = y
    if (is.numeric(y)) {
        rtype = "cont"
        if (is.null(highresp)) highresp = "h"
        else if (substring(highresp, 1) == "l") y = -y
        if (length(unique(y)) == 2) rtype = "bin"
    }
    else if (is.factor(y)) {
        if (is.null(highresp)) 
            highresp = sort(unique(y))[-1]
        y = NULL
        for (i in 1:length(highresp)) y = cbind(y, 1 * (yy == 
            highresp[i]))
        dimnames(y) = list(row.names(x), as.character(highresp))
        rtype = "fact"
        if (length(highresp) == 1) 
            rtype = "bin"
    }
    else if (length(unique(y)) == 2) {
        rtype = "bin"
        if (is.null(highresp)) 
            highresp = sort(unique(y))[2]
    }
    else return("Error: Unknown response type\n")
    if (is.null(highresp)) 
        highresp = sort(unique(y))[2]
    if (!is.matrix(y)) 
        y = matrix(y)
    i <- !apply(y, 1, function(x) all(is.na(x)))
    y <- y[i, , drop = F]
    x <- x[i, sort.list(catpred, dec = T),drop=F]
    if (rtype != "cont" & (nn <- sum(y)) <= 5) 
        return(cat(paste("Only N =", nn, " positive responses found in the data. ARF will stop.", 
            sep = ""), "\n"))
    catpred = sort(catpred, dec = T)
    if (is.null(dimnames(x)[[2]]))
        dimnames(x)[[2]] = paste("x", 1:ncol(x), sep = "")
    names(catpred) = dimnames(x)[[2]]
    p <- ncol(x)
    n <- nrow(x)
    namesid = 1:p
    names(namesid) = names(catpred)
    res <- NULL
    rr = list(jn = rep(0, 13), id = rep(T, n))
    
    ff = function(rr, nms = "", varl = varlist) {
        id0 <- rr$id
        if (rtype != "cont") {
            n0 = sum(id0, na.rm = T)
            q1 = t(y[id0, ]) %*% rep(1, n0)
            q2 = t(1 - y[id0, ]) %*% rep(1, n0)
            if (all(pmin(q1, q2) <= 5)) 
                return(NULL)
        }
        if (length(varl) == 0) 
            jn = jnodegr(x[id0,,drop=F ], y[id0, , drop = F],gr[id0], catpred, 
                rtype = rtype, minn, fr, out, const,robust)
        else {
            jn = jnodegr(x[id0, varl[1], drop = F], y[id0, , drop = F],gr[id0], 
                catpred[varl[1]], rtype = rtype, minn, fr, out, 
                const,robust)
            jn[1] = namesid[varl[1]]
        }
        if (is.null(jn) | length(jn) < 14) 
            return(NULL)
        jn = jn[sort.list(-jn[, 7])[1], , drop = F]
        nam = dimnames(jn)[[1]]
        if (catpred[jn[1]]) {
            id = match(x[, jn[1]], strsplit(nam, ",")[[1]])
            id = id0 & !is.na(id)
            id1 = id0 & !id
            id2 = NULL
            if(jn[,6]==100 ) return(NULL)
            m = jn[13]; m1 = jn[9]; m2=0
            if (m == sum(id0)) 
                return(NULL)
            setC = paste("{", paste(sort(unique(x[id, jn[1]])), 
                collapse = ","), "}", sep = "")
#            setR = paste("{", paste(sort(unique(x[id2, jn[1]])), 
#                collapse = ","), "}", sep = "")
            setL = paste("{", paste(sort(unique(x[id1, jn[1]])), 
                collapse = ","), "}", sep = "")
        }
        else {
            id <- cleanna(id0 & (x[, nam] <= jn[1, 4]) & (x[, 
                nam] >= jn[1, 3]))
            id1 <- cleanna(id0 & x[, nam] < jn[1, 3])
            id2 <- cleanna(id0 & x[, nam] > jn[1, 4])
m = jn[13]; m1 = jn[9]; m2= jn[11]
#            m <- sum(id, na.rm = T)
#            m1 <- sum(id1, na.rm = T)
#            m2 <- sum(id2, na.rm = T)
            if (length(jn)<14)  return(NULL)
            if (m == sum(id0))  return(NULL)
            if (m > 0) 
                setC = paste("[", paste(zapsmall(range(x[id, 
                  jn[1]]), 4), collapse = ","), "]", collpase = "", 
                  sep = "")
            if (m1 > 0) 
                setL = paste("[", paste(zapsmall(range(x[id1, 
                  jn[1]]), 4), collapse = ","), "]", collpase = "", 
                  sep = "")
            if (m2 > 0) 
                setR = paste("[", paste(zapsmall(range(x[id2, 
                  jn[1]]), 4), collapse = ","), "]", collpase = "", 
                  sep = "")
        }
        if (m > 0) {
            if (m < minn) 
                ter <- 1
            else ter <- 0
            rrr <- list(M = list(jn = c(unlist(jn)[c(1:8,14)], m = m, ter = ter, 
                fu = 0), id = id, setC))
        }
        else return(NULL)
        if (m1 > 0) {
           if(is.na(jn[10])) jn[10]=NA
            if (m1 < minn) ter = 1 else ter = 0
            rrr$L <- list(jn = c(unlist(jn[c(1, 2, 2, 3, 5)]), 
                mean(id1) * 100, 0, 0, jn[10], m = m1, ter = ter, fu = 0), id = id1, 
                setL)
        }
        if (m2 > 0) {
               if(is.na(jn[12])) jn[12]=NA
            if (m2 < minn) 
                ter <- 1
            else ter <- 0
            rrr$R <- list(jn = c(unlist(jn[c(1, 2, 4, 5, 5)]), 
                mean(id2) * 100, 0, 0, jn[12], m = m2, ter = ter, fu = 0), id = id2, 
                setR)
        }
        names(rrr) = paste(nms, names(rrr), sep = "")
        return(rrr)
    }
    res = ff(rr)
    if (length(varlist) > 0) 
        varlist = varlist[-1]
    l0 = 1
    lres = length(res)
    p = length(res$M[[1]])
    for (i in 1:nlayers) {
        for (j in l0:lres) {
            if (any(is.na(w <- res[[j]][[1]][p - (1:0)]))) 
                return("Error: NA's")
            else if (j < 64 & sum(abs(w)) == 0 & sum(res[[j]][[2]]) > 
                2 * minn) {
                res[[j]][[1]][p] <- 1
                res1 <- ff(res[[j]], names(res[j]), varlist)
                if (length(varlist) > 0) 
                  varlist = varlist[-1]
                if (is.null(res1)) 
                  res[[j]][[1]][p - (1:0)] <- 1:0
                else res = c(res, res1)
            }
        }
        l0 = lres + 1
        lres = length(res)
        if (l0 > lres) 
            break
    }
    res0 <- nam <- NULL
    for (i in 1:length(res)) {
        res0 <- rbind(res0, res[[i]][[1]])
        nam[i] = res[[i]][[3]]
    }
    i = 1:length(res)
    res <- res[i]
    res0 <- res0[i, ]
    ygr = res0[, 2]
    res0 <- data.frame(res0)
    res0[, 1] <- names(x)[res0[, 1]]
    res0[[2]] <- nam[i]
    res0[, p - 1] <- res0[, p - 1] + res0[, p] * 2
    res0$sign <- c("NS", "S")[res0[, 8] + 1]
    res0$node <- c("TE", "TE", "FU")[res0[, p - 1] + 1]
    res0 <- res0[, -c(3:5, 8, p - (0:1))]
    if (predict) {
        pp = array(NA, c(ncol(res0) - 7, n))
        for (i in 1:length(res)) if (res0$node[i] == "TE") 
            pp[, res[[i]][[2]]] <- unlist(res0[i, 5:(ncol(res0) - 
                3)])
        pp = t(pp)
        dimnames(pp) = list(dimnames(x)[[1]], highresp)
        if (rtype == "fact" | rtype == "bin") {
            library(MASS)
            uuu = data.frame(pp, yy)
            qq = lda(yy ~ ., data = uuu)
            pred = predict(qq)[1:2]
            pred$obj = qq
        }
        else pred = pp
    }
    Ave = apply(y[gr==1,,drop=F],2, mean, na.rm = T)-apply(y[gr==0,,drop=F],2, mean, na.rm = T)
    res0[,3] = round(res0[,3],2)
    dimnames(res0) <- list(names(res), c("Var", "Range", 
        "%InSubset", "Statistic", "Change", "N", "Sf", "NdTy"))
    return(list(tree = res0, data = c(N = nrow(x), Ave), resp = rtype, 
        pred = if (predict) pred else NULL, call = call, vars = names(x), 
        if (rtype == "fact") highresp[ygr] else NULL))
}
