.packageName <- "erf"
`f.ct2` <-
function (x, y, qi = c(0.2,0.4,0.6,0.8,0.9,0.95,0.99,0.999,.9999), bsz = 200, plotenv = F, tol = 10^(-10))
{
### Raws of x are Genes, Columns of x are samples  #####
    library(quantreg)
###
    if(!is.matrix(x)) x = matrix(x,ncol=1)
    if(!is.matrix(y)) y = matrix(y,ncol=1)
###
    x <- f.toarray(x)
    y <- f.toarray(y)
    xsp <- f.rsd(cbind(x, y))
    isp = !is.na(xsp)
    xx = x[isp, ]
    yy = y[isp, ]
    xsp = f.rsp(xx, yy)
    nr <- nrow(xx)
    dd <- dim(xx)
    dy <- dim(yy)
    #xt <- c(f.rtt(xx, yy))
    xt <- c(f.rtt2(xx, yy)[,1])
    xspp <- xsp
    u = cbind(xx[abs(xt) < 1, ], yy[abs(xt) < 1, ])
    u = (u - f.rmean(u))/f.rsd(u)
    sxps <- sort(xsp)
    for (l in 1:5) {
        xsp0 <- xspp
        xsps <- sample(xsp0, rep = F)
        xsp1 <- NULL
        for(i in 1:5) {
        x1 <- array(sample(u,2*dd[1]*dd[2],rep=T), c(2*dd[1],dd[2])) * rep(xsps,2)
        x2 <- array(sample(u,2*dy[1]*dy[2],rep=T), c(2*dy[1],dy[2])) * rep(xsps,2)
###
    if(!is.matrix(x1)) x1 = matrix(x1,ncol=1)
    if(!is.matrix(x2)) x2 = matrix(x2,ncol=1)
###
        xsp1 <- c( xsp1,f.rsp(x1, x2)) }
        xsps <- sort(xsp1)[(1:nr) * 10 - 5]
        sxps0 = sort(xsp0)
        xspp = f.smdecreasing(smooth.spline(xsps,sxps),sxps0,F)
    }
    xsps <- sample(xspp, rep = F)
    pnnn=prod(dd);pnny=prod(dy); xt1<-xsp1<-NULL
#   for (i in 2:(bsz%/%50)) {
        xnn1 <- array(sample(u,pnnn,rep=T), dd) * xsps
        xnn2 <- array(sample(u,pnny,rep=T), dy) * xsps
###
    if(!is.matrix(xnn1)) xnn1 = matrix(xnn1,ncol=1)
    if(!is.matrix(xnn2)) xnn2 = matrix(xnn2,ncol=1)
###
        #xt1 <- c(xt1,f.rtt(xnn1, xnn2))
        xt1 <- c(xt1,f.rtt2(xnn1, xnn2)[,1])
        xsp1 <- c(xsp1,f.rsp(xnn1, xnn2))
#   }
  
l1 = log(xsp1[i <- sample(length(xsp1),10000)])
l2 = log(abs(xt1[i]))
ccc = rq(l2~l1+I(l1^2)+I(l1^3),qi)$coef
m1 = log(xsp); m2 = log(abs(xt))
out = cbind(abs(xt),exp(cbind(1,m1,m1^2,m1^3)%*%ccc),xsp)
dimnames(out) = list(rownames(xx),c("T", paste("Curve",qi, sep = ""),"Sp"))
if (all(isp)) return(out)
res = array(0, c(nrow(x), ncol(out)), dimnames = list(rownames(x), 
        colnames(out)))
res[isp, ] = out
res
}

`f.erf` <-
function(x,y,xtest,ytest,nsim=1000,www,nv,CONS=0.99) {
### Rows of x are samples, Columns of x are genes  #####
### nv: Number of variables randomly sampled as candidates at each split (mtry in RF) ###
###     the default nv is sqrt(p) ########################
### www : weight method(T ot CT). The default is equal weight which is ordinary RF  ####

library(rpart)
library(DNAMR)
n = nrow(x)
p = ncol(x)
tx = f.toarray(t(x))
if(!is.factor(y)) y=factor(y)
if ( missing(nv)) nv = ceiling(sqrt(p))
if ( missing(www)) www =rep(1,p)/p

if(missing(xtest)) { nt = 0; xtest<-ytest<-idt<-NULL} else {
   nt = nrow(xtest)
   y = c(y,rep(NA,nt))
   idt=(n+1):(n+nt)
}
minn = n/2 +2
x = rbind(x,xtest)
res = array(0,c(n+nt,nlevels(y)))
nid0 = rep(0,n+nt)
imp= inamp = NULL
if(!is.data.frame(x)) x=data.frame(x)
if(is.null(dimnames(x)[[2]])) dimnames(x)[[2]]=paste("x",1:p,sep="")

for(i in 1:nsim) {

id = 0
while(length(id) <= minn) id = unique(sample(n,rep=T))
 
ww <- if (www=='T') f.wcomp(tx[,id],y[id],CONS,fun=f.runt)   
else if (www=='CT') f.wcomp(tx[,id],y[id],CONS,fun=f.runct)
else www   

nid=sort(c(c(1:n)[-id],idt))
yy = y
yy[nid]=NA
impp = f.forest(x,yy,minn,ww,nv)
inamp = c(inamp,nchar(rownames(impp[[1]])[-1])[c(T,F)])
imp = c(imp,as.character(impp[[1]][-1,1][c(T,F)]) )
pp=impp[[2]]

res[nid,] = res[nid,] + pp[nid,]
nid0[nid] = nid0[nid]+1
}

res = res/nid0
res = names(table(y)) [ apply(res,1,function(x) sort.list(-x)[1])]

if(nt > 0) {
rest = res[-(1:n)]
errt = mean(rest != ytest, na.rm=T) 
} else { rest= errt=NULL}
 res = res[1:n]
err = mean(res != y,na.rm=T)  # misclassification rate 
list(res=res,rest=rest, errorrate=c(err,errt) ) # out-of bag error rates
}

`f.erf.cv` <-
function(x,y,xtest,ytest,nsim=1000,www,nv,CONS=0.99) {

### Rows of x are samples, Columns of x are genes  #####
### nv: Number of variables randomly sampled as candidates at each split (mtry in RF) ###
###     the default nv is sqrt(p) ########################
### www : weight method(T or CT). The default is equal weight which is ordinary RF  ####

library(rpart)
library(DNAMR)
n = nrow(x)
p = ncol(x)
tx = f.toarray(t(x))
if(!is.factor(y)) y=factor(y)
if ( missing(nv)) nv = ceiling(sqrt(p))
if ( missing(www)) www = rep(1,p)/p 

if(missing(xtest)) { nt = 0; xtest<-ytest<-idt<-NULL} else { 
   nt = nrow(xtest)
   y = c(y,rep(NA,nt))
   idt=(n+1):(n+nt)
}
minn = n/2 + 2
x = rbind(x,xtest)
res = array(0,c(n+nt,nlevels(y)))
nid0 = rep(0,n+nt)
imp= inamp = NULL
if(!is.data.frame(x)) x=data.frame(x)
if(is.null(dimnames(x)[[2]])) dimnames(x)[[2]]=paste("x",1:p,sep="")
w0 = NULL 
for(i in 1:n) {
id = (1:n)[-i]
w0 <- cbind( w0, if (www=='T') f.wcomp(tx[,id],y[id],CONS,fun=f.runt)   
else if (www=='CT') f.wcomp(tx[,id],y[id],CONS,fun=f.runct)   
else www)
}

for(i in 1:nsim) {
id = (i%%n +1)
ww = w0[,id]
nid=sort(c(id,idt))
yy = y
yy[nid]=NA

impp = f.forest(x,yy,minn,ww,nv)
inamp = c(inamp,nchar(rownames(impp[[1]])[-1])[c(T,F)])
imp = c(imp,as.character(impp[[1]][-1,1][c(T,F)]) )
pp=impp[[2]]

res[nid,] = res[nid,] + pp[nid,]
nid0[nid] = nid0[nid]+1
}

res = res/nid0

res = names(table(y)) [ apply(res,1,function(x) sort.list(-x)[1])] 

if(nt > 0) {
rest = res[-(1:n)]
errt = mean(rest != ytest, na.rm=T) 
} else { rest= errt=NULL}
 res = res[1:n]
err = mean(res != y,na.rm=T) # misclassification rate 
list(res=res,rest=rest, errorrate=c(err,errt) ) # out-of bag error rates
}

`f.forest` <-
function(x,y,minn=4, ww, nv) {
call = match.call() # save the command in the output
if(!is.data.frame(x)) x = data.frame(x) # data frame in not the same as matrix

# Find out which predictor variables are categorical
catpred=sapply(x,function(z) if(length(unique(z))<=2) T else
                                if(is.numeric(z)) F else T)

if(!is.matrix(y)) dim(y) = c(length(y),1) # y is a matrix

x <- x[,sort.list(catpred,dec=T)] # put categorical variables first
catpred = sort(catpred,dec=T) # sort the var list
n = nrow(x) 
p = ncol(x)

if(is.null(dimnames(x)[[2]])) dimnames(x)[[2]] = paste("x",1:p,sep="") #varnames
names(catpred) = dimnames(x)[[2]] # Assign Names
namesid = 1:p; names(namesid) = names(catpred) # Names id
res <- NULL
rr = list(list( jn = rep(0,13), id = 1:n,status="FU")) # top node
k0 = 0

pr = array(-1, c(n,if(is.factor(y)) nlevels(y) else 1))
for(j in 1:12) { k=k0+1; k0=length(rr)
         if(k0>=k)  for( i in k:k0 ) if(rr[[i]]$status !="TE"){ 
# If the node is not terminal then split it
            id0 = rr[[i]]$id

v0 = sort(f.sample(p,nv,ww))
            if( sum(!is.na(y[id0]))<= minn) rr[[i]]$status = "TE" else {
                xx = x[id0,v0]
                yy = y[id0]
                w = f.rnode(xx,yy)

if(!is.null(w)){
                pr[id0,] = w$pred
                w$R$id = id0[w$R$id]
                w$L$id = id0[w$L$id]
                 iiR = ( length(w$R$id) - max(table( y[ w$R$id] ) ) )<=3
                 iiL = ( length(w$L$id) - max(table( y[ w$L$id] ) ) )<=3
                w$R$status = if(length(w$R$id)<= minn| iiR) "TE" else "FU"
                w$L$status = if(length(w$L$id)<= minn| iiL) "TE" else "FU"
                names(w) = paste(names(rr)[i],names(w),sep="")

		rr = c(rr,w[1:2]) } else rr[[i]]$status="TE"
            }
      }
}
# cat("end of loop\n")
 rr = rr[sapply(rr, function(x) length(x$id) > 0)]
res=data.frame(Name="TOP",Split=0,Clrate=0,N=nrow(x),NodeType="FU")
if(length(rr)>=2) for(i in 2:length(rr))  { 
 u=rr[[i]]
 if(length(u[[2]]) > 1) u[[2]] = paste(u[[2]],collapse=",")
 res=rbind(res,data.frame(Name=u[[1]],Split=u[[2]],Clrate=u[[3]],
                  N=length(u[[4]]),NodeType=u[[5]]))
}
rownames(res) = names(rr)
list(tab=res,pred=pr)
}

`f.rnode` <-
function(x,y) {
x=as.data.frame(x)
if(is.factor(y)){
  out = array(0,c(nrow(x),nlevels(y)),dimnames=list(rownames(x),levels(y)))
  y = factor(as.character(y))
}
tr = rpart(y~., data=x,control=rpart.control(cp=0.,minsplit=4))
rp2 = path.rpart(tr,2,print.it=F)
if (length(rp2) <1) return(NULL)
tt = list(tr[[1]][1,1], rp2[[1]][2],side="L")
tt1 = list(tt[[1]], path.rpart(tr,3,print.it=F)[[1]][2],side="R")
tt$id <- snip.rpart(tr,2:3)$where ==2
tt1$id <- snip.rpart(tr,2:3)$where ==3
out[,levels(y)] = predict(tr,x)

return(list(R=tt,L=tt1,pred=out))
}

`f.rsp` <-
function (x,y, n = ncol(x),m=ncol(y)) 
 sqrt(c(cbind((x - f.rmean(x))^2,(y - f.rmean(y))^2) %*% rep(1, n+m))/(n+m - 2))

`f.rtt2` <-
function (x1, x2, fu = 0,paired=F, num.thresh = 10^(-6), denom.thresh = 10^(-6)) 
{
if(paired | missing(x2)) {
    if (missing(x2)) x = x1 else  x = x2 - x1
    num = f.rmean(x)
    den = t(array(fu, c(nrow(x1), length(fu)))) + f.rsd(x)/sqrt(ncol(x))
    }  else {
        if(!is.matrix(x1)) x1 = matrix(x1,ncol=1)
        if(!is.matrix(x2)) x2 = matrix(x2,ncol=1)
    num = (f.rmean(x1) - f.rmean(x2))
    den = (t(array(fu, c(nrow(x1), length(fu)))) + f.rssp(x1, 
        x2))
     } 
    i = abs(num) < num.thresh & den < denom.thresh
    num[i] = 0
    den[i] = 1
        tt=c(num/den)
    cbind(T=tt,Pval=2-2*pt(abs(tt),ncol(x1)+ncol(x2)-2))
}

`f.runct` <-
function(x,gr) {
### Rows of x are Genes, Columns of x are samples  #####
y1=as.numeric(factor(gr))
f.ctpval(f.ct2(x[,y1==1],x[,y1==2]))
}

`f.runt` <-
function(x,gr) {
### Rows of x are Genes, Columns of x are samples  #####
y1=as.numeric(factor(gr))
f.rtt2(x[,y1==1],x[,y1==2])[,2]
}

`f.sample` <-
function(p,nv,w) { 
k = NULL
if(!is.matrix(w))  return(sample(1:p,nv,rep=F,prob=w))
for(i in 1:ncol(w)) 
k =c(k, sample(1:p,nv,rep=F,prob=w[,i]))
sample(k,nv,rep=F)
}

`f.scramble` <-
function(x=rma0res,k=3) {
## only for 12 samples with 2 groups and even division(6:6 )####
ux = sort(unique(x))
n = length(x)
if(!all(table(x)==6) | length(ux) != 2 ) return(sample(x))
while(T) {
tt = table(x,jj <- sample(x))
if(tt[1,1] == (n/2-k) & tt[2,2] == (n/2-k) ) 
      break}
jj
}

`f.wcomp` <-
function(x,gr,cons=0.99,fun=f.runt) {
### Rows of x are Genes, Columns of x are samples  #####
u = NULL
u=fun(x,gr)
u=f.wfda(u,cons)
u / sum(u)
}

`f.wfda` <-
function(x,k=0.99){
n = length(x)
u = x[sort.list(x)]
u = c((u[-1] + u[-n])/2,u[n])
u[sort.list(x)]= u/(1:n)*n;
u[ u > 1 ]= 1
u[ u < 0.001] = 0.001
u =1/u -k
u = fmonotone(u,-x)
u
}

`f.wfdap` <-
function(u,k=0.99){
u[ u < 0.001] = 0.001
1/u -k
}

`fmonotone` <-
function(i,ii,n=length(i)){i=i[sort.list(ii)] ;
for( j in 2:n) i[j] = max(i[j],i[j-1]);
 i[rank(ii)]}

